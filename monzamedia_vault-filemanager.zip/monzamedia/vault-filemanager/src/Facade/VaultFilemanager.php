<?php namespace Monzamedia\VaultFilemanager\Facade;

use Illuminate\Support\Facades\Facade;

class VaultFilemanager extends Facade {

    protected static function getFacadeAccessor() {

        return 'vault-filemanager';

    }

}
