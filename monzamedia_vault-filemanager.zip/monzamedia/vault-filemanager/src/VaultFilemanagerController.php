<?php namespace Monzamedia\VaultFilemanager;

use App\Http\Controllers\Controller;
//use Illuminate\Routing\Controller;
//use App\Http\Controllers\other\controllers
//use Auth;

//use Illuminate\Http\Request;
use Illuminate\Http\Request;
//use App\Models\SiteNotification;

/* Facade Includes */
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Input;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\DB;
//use Illuminate\Http\Request;

class VaultFilemanagerController extends Controller {
    public $trash_dir    = 'assets/uploads/_trash';
    public $media_dir    = 'assets/uploads';
    public $data         = [];
    private $library     = [];
    private $folders     = [];
    private $DS          = '/';
    private $ops_dir     = null;
    private $public      = null;
    public $storage_info = [];
    private $validators  = [
        'email_address' => "/(?:([a-zA-Z0-9!#$%&'*+-\/=?^_`{|}~]*?)@(([a-zA-Z0-9-]*).([a-zA-Z0-9]{2,4})))/",
    ];

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct( ) {
        $this->data['media_items']  = [];
        $this->data['media_search'] = [];
        $this->data['trash_can']    = $this->trash_dir;
        $this->data['errors']       = [];

        $this->data['folder_size']  = 0;
        $this->data['server_os']    = $this->get_OS();
        $this->storage_stats();

        //$this->allowedTypes      = Config::get( 'config/filemanager_image_types' );
        //$this->allowedImageTypes = $this->allowedTypes['allowed_images'];
        //$this->otype_arr         = $this->allowedTypes['file_kinds'];
/**/
        $this->allowedTypes         = [ 'csv', 'doc', 'docx', 'gif', 'jpg', 'jpeg', 'pdf', 'png', 'rar', 'svg', 'txt', 'xls', 'xlsx', 'zip', ];//
        $this->allowedImageTypes    = [ 'gif', 'jpg', 'jpeg', 'png', 'svg', ];//
        $this->otype_arr            = [
            'rar'  => ['fa fa-file-word-o','/assets/images/filemanager/icons/file_rar_icon.png','/assets/images/filemanager/icons/svg/file_rar_icon.svg'],
            'txt'  => ['fa fa-file-word-o','/assets/images/filemanager/icons/file_txt_icon.png','/assets/images/filemanager/icons/svg/file_txt_icon.svg'],
            'zip'  => ['fa fa-file-word-o','/assets/images/filemanager/icons/file_zip_icon.png','/assets/images/filemanager/icons/svg/file_zip_icon.svg'],
            'csv'  => ['fa fa-file-word-o','/assets/images/filemanager/icons/file_csv_icon.png','/assets/images/filemanager/icons/svg/file_csv_icon.svg'],
            'pdf'  => ['fa fa-file-pdf-o','/assets/images/filemanager/icons/file_pdf_icon.png','/assets/images/filemanager/icons/svg/file_pdf_icon.svg',],
            'doc'  => ['fa fa-file-word-o','/assets/images/filemanager/icons/file_docx_icon.png','/assets/images/filemanager/icons/svg/file_docx_icon.svg'],
            'docx' => ['fa fa-file-word-o','/assets/images/filemanager/icons/file_docx_icon.png','/assets/images/filemanager/icons/svg/file_docx_icon.svg'],
            'xls'  =>  ['fa fa-file-word-o','/assets/images/filemanager/icons/file_xlsx_icon.png','/assets/images/filemanager/icons/svg/file_xlsx_icon.svg'],
            'xlsx' => ['fa fa-file-word-o','/assets/images/filemanager/icons/file_xlsx_icon.png','/assets/images/filemanager/icons/svg/file_xlsx_icon.svg'],
            'unknown' => 'fa fa-question',
        ];//
        $this->allowedTypes['default_timezone'] = 'Africa/Johannesburg';
        $this->allowedTypes['allowed_images'] = [ 'gif', 'jpg', 'jpeg', 'png', 'svg', ];
/**/
        date_default_timezone_set( 'Africa/Johannesburg' );//$this->allowedTypes['default_timezone'] );
    }
    public function index() {
        $tmp    = Input::get( 'folder' );
        $folder = ( null !== $tmp ) ? $tmp : $this->media_dir;
        $size   = ( int ) 0;
        //if ( $folder != null ){
            $items  = $this->listFiles( $folder, 'fav|thumbs', 'nowalk' );
        //} else {
        //    $folder = $this->media_dir;
        //    $items  = $this->listFiles( $folder, 'fav|thumbs', 'nowalk' );
        //}
        $fulllist = $this->listFiles( $folder, '__none__',   'walk' );
        $size     = array_reduce( array_map( "filesize", $fulllist ), [ __CLASS__,"sum" ] );
        $this->data['folder_size'] = $this->size_human( $size );
        //dd( $items );
        //$items    = $this->natural_sort( $items );
        unset( $fulllist );
        $fulllist = array();
        /*
        foreach( $items as $item ) {
            array_push( $this->data['media_items'], 
                        $this->html_markup( $this->fs_obj_props( $item ) ) );
        }
        */
        $this->data['media_objects'] = array_map( [ __CLASS__, 'fs_obj_props' ], $items );
        /*
        var_dump( $this->data['media_objects'] );
        $this->data['media_objects'] = $this->array_msort(
            $this->data['media_objects'], array( 'name'=>SORT_DESC, 'szcnt'=>SORT_ASC )
        );
        dd( $this->data['media_objects'] );
        */
        //$this->data['media_items'] = $this->data['media_objects'];
        //dd( $this->data['media_objects'] );
        $this->data['breadcrumbs']  = $this->breadcrumbs( $folder );
        $this->data['folder'] = ( string ) $folder;
        //$view = view( 'vault.filemanager.listing', $this->data )->render();
        //return response()->json(['html'=>$view]);
        //dd( $this, $fulllist, $size, $this->data['folder_size'] );
        return view( 'vaultfilemanager::vfm', $this->data );
    }
/*
    private function array_msort( $array, $cols ) {
        $colarr = array();
        foreach ( $cols as $col => $order ) {
            $colarr[$col] = array();
            foreach ( $array as $k => $row ) {
                if ( ! is_array( $row[$col] ) ) {
                    $colarr[$col]['_'.$k] = strtolower( $row[$col] );
                } else {
                    foreach ( $array as $k => $row ) {

                    }
                }
            }
        }
        $eval = 'array_multisort(';
        foreach ( $cols as $col => $order ) {
            $eval .= '$colarr[\''.$col.'\'],'.$order.',';
        }
        $eval = substr( $eval,0,-1 ).');';
        eval( $eval );
        $ret = array();
        foreach ( $colarr as $col => $arr ) {
            foreach ( $arr as $k => $v ) {
                $k = substr( $k, 1 );
                if ( ! isset( $ret[$k] ) ) $ret[$k] = $array[$k];
                $ret[$k][$col] = $array[$k][$col];
            }
        }
        return $ret;
    }
*/  

    // Set current operating/current working directory path
    private function _alias_cwd( Request $request, $pth=null ) {
        if ( null !== $pth ) {
            $pth = $this->clean_string( $pth );
            if ( is_dir( $pth ) && file_exists( $pth ) ) {
                $this->ops_dir = $pth;
            } else {
                return ( bool ) false;
            }
        } else if ( null !== $request->input( 'folder' ) ) {
            $this->ops_dir = $request->input( 'folder' );
        } else {
            return ( bool ) false;
        }
        return ( bool ) true;
    }
    private function _get_public_path() {
        if ( function_exists( 'public_path' ) ) {
            $tmp_pth = ( string ) public_path();
        } else {
            $tmp_pth = ( string ) $_SERVER['DOCUMENT_ROOT'];
        }
        if ( strtolower( $this->get_OS() ) === 'win' ) {
            $tmp_pth = ( string ) preg_replace( '/\\\/i', '/', $tmp_pth );
        }
        return $tmp_pth;
    }
    /**
     * Stupid loop from A-Z, which corresponds with windows drive letters
     * 
     * IF letter is a directory and it exists (no matter the permissions):
     *  adds to win_drives array
     * ELSE
     *  continue
     */
    private function _find_attached_drives() {
        $drv_mounted = [];
        $drv_letters = str_split( 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' );
        foreach ( $drv_letters as $ltr ) {
            $tmp = $ltr . ':';
            if ( is_dir( $tmp ) && file_exists( $tmp ) ) {
                $tmp_key = strtolower( $ltr );
                $tmp_val = strtoupper( $tmp );
                $drv_mounted[$tmp_key] = $tmp_val;
            }
        }
        return $drv_mounted;
    }
    /**
     * WINDOWS ONLY Function - USELESS ON LINUX/MAC etc.
     * 
     * Returns the drive letter on which the server is running/stored.
     * It is unaware of any other mounted or installed disks/partitions.
     * 
     */
    private function _root_symbol() {
        $this->_find_attached_drives();
        if ( null !== $this->public ) {
            $drv_ltr = substr( $this->public, 0, 2);
        } else {
            $drv_ltr = substr( $this->_get_public_path(), 0, 2);
        }
        return $drv_ltr;
    }
    private function storage_stats() {
        /* TOTAL */
        $this->_get_diskspace_capacity();
        /* FREE */
        $this->_get_diskspace_available();
        /* USED */
        $this->_get_diskspace_allocated();
        /**/
        $u = ( float ) $this->data['store_used'];
        $t = ( float ) $this->data['store_total'];
        /**/
        $this->data['disk_stats'] = round( ( float ) ( ( $u / $t ) * 100 ), 2 );
    }
    private function _get_diskspace_capacity() {
        $total = $this->get_storage_stats()['total'];
        $k     = ( is_array( $total ) ) ? array_keys( $total ) : null;
        $this->data['store_total'] = ( is_array( $total ) ) ? $total[$k[0]] : $total;
    }
    private function _get_diskspace_available() {
        $free  = $this->get_storage_stats()['free'];
        $k     = ( is_array( $free ) ) ? array_keys( $free ) : null;
        $this->data['store_free']  = ( is_array( $free ) ) ? $free[$k[0]] : $free;
    }
    private function _get_diskspace_allocated() {
        $used  = $this->get_storage_stats()['used'];
        $k     = ( is_array( $used ) ) ? array_keys( $used ) : null;
        $this->data['store_used']  = ( is_array( $used ) ) ? $used[$k[0]] : $used;
    }
    private function dir_path_clean($p) {
        return preg_replace( '/(^uploads\/images\/|\.$)/i', '', $p );
    }
    public function json_tree() {
        $this->folders = array_map(
            array( $this, 'dir_path_clean' ), $this->glob_recursive( $this->media_dir . '/' . 'images/.' )
        );
        $base_dir = $this->media_dir;
        if ( ! headers_sent() ) {
            header( 'HTTP/1.1 200 OK' );
            header( 'Content-Type: application/json' );
        }
        echo json_encode( $this->php_file_tree_dir( $base_dir, '' ) );
        exit();
    }
    private function sum( $carry, $item ) {
        $carry += $item;
        return $carry;
    }
    private function natural_sort( $arr, $case=false ) {
        return ( $case ) ? natcasesort( $arr ) : natsort( $arr );
    }
    private function fs_obj_props( $item ) {
        $bnme = ( string ) basename( $item );
        $bnme = preg_replace( '/(\.\w+)?$/i', '', $bnme );
        if ( ! is_dir ( $item ) ) {
            $this->library[$bnme]['type'] = ( string ) filetype( $item );
            if ( preg_match( '/(\.\w+)$/i', basename( $item ), $m ) ) {
                $ext = pathinfo( $item )['extension'];
                $fnm = pathinfo( $item )['basename'];
                $tmp = pathinfo( $item )['dirname'];
                $fle = pathinfo( $item )['filename'];    
            } else {
                $ext = '';
                $fnm = basename( $item );
                $tmp =  dirname( $item );
                $fle = basename( $item );
            }
            $pth = ( substr( $tmp, 0, 1 ) !== '/' ) ? '/' . $tmp : $tmp;
            $sze = $this->get_stats( $item )['size'];
            $this->library[$bnme]['display_name'] = $this->urlify_filenames( ( string ) basename( $item ) );
            $this->library[$bnme]['name']  = ( string ) basename( $item );
            $this->library[$bnme]['path']  = ( string ) dirname( $item );
            $this->library[$bnme]['kind']  = strtolower( $ext );
            $this->library[$bnme]['szcnt'] = [ 'bytes'=>$sze, 'human'=>$this->size_human( $sze ) ];
            $this->library[$bnme]['stats'] = $this->get_stats( $item );
            /*
            if ( in_array( $ext, $this->allowedTypes['allowed_images'] ) ) {
                $thmb_dst = $this->media_dir . '/' . 'media_thumbs' . '/' . $fnm;//$config['media_thumbs'] . '/' . $fnm;
                $this->createThumbnail( $item, $thmb_dst, 120 );
                $img      = "<img class='img-thumb' src='" . $this->show_relpath( $thmb_dst );
                $this->library[$bnme]['thumbloc'] = (string) $this->show_relpath( $thmb_dst );
            } else if ( $ext == 'svg' ) {
                $thmb_dst = $item;
                $img = "<img class='img-thumb bg-black' src='" . $this->show_relpath( $item );
                $this->library[$bnme]['thumbloc'] = (string) $this->show_relpath( $item );
            }
            */
            $dnm     = ( substr( $this->show_relpath( $item ), 0, 1 ) !== '/' ) ? 
                        '/' . $this->show_relpath( $item ) : 
                            $this->show_relpath( $item );
        } else {
            $this->library[$bnme]['type']  = ( string ) filetype( $item );
            $tmp = $this->show_relpath( $item );
            $pth = ( substr( $tmp, 0, 1 ) !== '/' ) ? '/' . $tmp : $tmp;
            $sze = ( int ) $this->directory_item_count( $item );
            $ext = 'FOLDER';
            $this->library[$bnme]['display_name'] = $this->urlify_filenames( ( string ) basename( $item ) );
            $this->library[$bnme]['name']  = ( string ) basename( $item );
            $this->library[$bnme]['path']  = ( string ) dirname( $item );
            $this->library[$bnme]['kind']  = strtolower( $ext );
            $this->library[$bnme]['szcnt'] = ['items'=>$sze];
            $this->library[$bnme]['stats'] = $this->get_stats( $item );
        }
        $obj = $this->library[$bnme];
        //dd( $obj );
        return $obj;
    }

    private function shortcode_copy_move_dest( $e=null, $p=null ) {
        if ( ! isset( $p ) || is_null( $p ) || empty( $p ) || ( string ) $p === '' ) return;
        if ( ! isset( $e ) || is_null( $e ) || empty( $e ) || ( string ) $e === '' ) return;
        $o = ( ! preg_match( '/(\.$)?/i', $p, $m ) ) ? $p :
                $this->iterate_filename( basename( $e ), dirname( $p ) );
        //dd( $e, $p, $o );
        return $o;
     }
    /**
     * Media Item Rename/Move Endpoint
     * 
     * Calls partner function to do actual object rename
     * or moving. The MOVE functionality will not be
     * obvious to non-Linux users.
     * 
     * To use this function as MOVE - input should be of the
     * form {destination/directory/or/folder}/{this_filename}
     * 
     */
    public function item_rename( Request $request ){
        $this->_alias_cwd( $request );
        $folder = rtrim( ( string ) $this->ops_dir, '/' );
        $ifile = $folder . '/' . $request->input( 'ifile' );
        $ofile = $folder . '/' . $request->input( 'ofile' );
        $ofile = $this->shortcode_copy_move_dest( $ifile, $ofile );
        //dd( $ifile, $ofile );
        if ( $this->rename_item( $ifile, $ofile ) ) {
            return Redirect::back();
        }
        /*else {
            // Error/Exception HANDLER
        }
        */
    }
    private function rename_item( $s=null, $d=null ) {
        if ( ( ! isset( $s ) || is_null( $s ) ) || ( ! isset( $d ) || is_null( $d ) ) )
            exit( "\r\nNO Inputs Supplied\r\n" );
        $oldname = file_exists( $s ) ? $s: null;
        $newname = ( is_dir( $s ) && file_exists( $d ) ) 
            ? $this->iterate_filename( basename( $d ), dirname( $d ) )
            : $d;
        if ( ( $oldname == $newname) || ! isset( $newname ) || 
            ( is_null( $newname ) || is_null( $oldname ) ) || $newname == '' ) {
            return false;
        }
        if ( ! is_null( $oldname ) && file_exists( $oldname ) && ( null !== $newname || '' !== $newname ) ) {
            return rename( $oldname, $newname );
        }
    }

    /**
     * 
     * Get the OS type (and, optionally any further details).
     * 
     */
    public function get_OS( $opt='s' ) {
        $osis = $itis = '';
        switch( $opt ) {
            case ( 'n' ):
            case ( 'r' ):
            case ( 'v' ):
            case ( 'm' ):
                return php_uname( $opt );
                break;
            case ( 'a' ):
            case ( 's' ):
                $osis = php_uname( $opt );
                $itis = $this->os_recognize( $osis );
                break;
            default:
                $osis = PHP_OS;
                $itis = $this->os_recognize( $osis );
        }
        unset( $opt, $osis );
        return $itis;
    }

    /**
     * Recognize the server operating system and return
     * layman string name.
     * 
     * LINUX-like: /(linux|ubuntu|gnu|dragonfly|haiku|bsd|sunos|solaris)?/i;
     * Mac /(darwin|mac|macos|os[s]erver|appleserver)?/i; or
     * Windows /(window[s][_NT])?/i.
     *
     * input: OS string from a command like uname( -a|s ); and
     * return: layman os terms or false for unknown os'
     * 
     */
    private function os_recognize( $osstr ) {
        $os_recg = [
            'linux'     => [
                "((linux|ubuntu|gnu|dragonfly|haiku|bsd|sunos|solaris)+?[\s+-_]?(server)*?)+?",
                "linux",
            ],
            'macintosh' => [
                "(darwin|mac[os]*?[\s+-_server]*)+?",
                "mac",
            ],
            'windows'   => [
                "(win[dow[s]?]*?[\s+-_server]*?[_]*?nt)+?",
                "win",
            ],
            'unknown'   =>  [
                null,
                false,
            ],
        ];
    // LINUX-like
        if ( preg_match( '/' . $os_recg['linux'][0] . '/i', $osstr, $m ) ) {
            return $os_recg['linux'][1];
    // MAC
        } else if ( preg_match( '/' . $os_recg['macintosh'][0] . '/i', $osstr, $m ) ) {
            return $os_recg['macintosh'][1];
    // WIN
        } else if ( preg_match( '/' . $os_recg['windows'][0] . '/i', $osstr, $m ) ) {
            return $os_recg['windows'][1];
    // UNKNOWN
        } else {
            echo "Unknown string: $osstr";
        }
        return $os_recg['unknown'][1];
    }

    /**
     * Get the storage statistics
     * 
     * Convert to percentage used and free and
     * feed to the frontend for display.
     * 
     * Total disk size also available
     * 
     */
    private function get_storage_stats() {
        $store = [];
        //if ( ! isset( $this->data['server_os'] ) || is_null( $this->data['server_os'] ) ) return;
        if ( null === $this->data['server_os'] ) return;
        switch( $this->data['server_os'] ) {
            case 'mac':
            case 'linux':
                $disk_total = $this->size_human( disk_total_space( "/" ) );
                $free_space = $this->size_human( disk_free_space( "/" ) );
                $used_space = $this->size_human( abs( $disk_total - $free_space ) );
            case 'win':
                /* Get Server Root and All Available Drives */
                $str_drv = $this->_root_symbol();
                $drvs_on = $this->_find_attached_drives();
                $disk_total = disk_total_space( $str_drv );
                $free_space = disk_free_space( $str_drv );
                $used_space = abs( $disk_total - $free_space ) ;
        }
        $store['total'] = $this->size_human( $disk_total );
        $store['free']  = $this->size_human( $free_space );
        $store['used']  = $this->size_human( $used_space );
        return $store;
    }

    /**
     * File is the basename of the filename input; and
     * Path is the dirname of the DESTINATION folder.
     * 
     */
    private function iterate_filename( $file, $path='.' ) {
        $file = ( isset( $file ) || ! is_null( $file ) || $file != '' ) ? '/' . $file : '';
        $fnme = preg_split( '/(\.)/i', $file );
        $extn = ( count( $fnme ) > 1 ) ? '.' . end( $fnme ) : null;
        $tmp  = $path . $file;
        $f    = ( ! is_null( $extn ) ) ? preg_replace( '/(' . $extn . ')$/i', '', $file ) : $file;
        $fpth = $path . $f;
        if ( file_exists( $fpth . $extn ) ) {
            $i  = 0;
            $fpth = $fpth . "-$i";
            while( file_exists( $fpth . $extn ) && ( $i < 100 ) ) {
                $j = $i + 1;
                $fpth = preg_replace( "/\d+$/", $j, $fpth );
                $i++;
            }
            $new = $fpth;
        } else {
            $new = $fpth;
        }
        return $new . $extn;
    }
    /**
     * String Cleaner and/or Pre-Sanitizer
     * 
     * This method will take an input string (NOT ARRAY),
     * and will perform the following string operations:
     *  > trim;
     *  > strip_tags;
     *  > stripslashed; and
     *  > htmlspecialchars (ENT_QUOTE, 'UTF-8')
     * in that order and returns the CLEANED string.
     * 
     */
    private function clean_string( $str ) {
        if ( ! isset( $str ) || is_null( $str ) || $str == '' ) return $str;
        $tmp = ( string ) $str;
        $tmp =             trim( $tmp );
        $tmp =       strip_tags( $tmp );
        $tmp =     stripslashes( $tmp );
        $tmp = htmlspecialchars( $tmp );
        return $tmp;
    }
    /**
     * Recursively Removes/Trashes An Item
     * 
     * In conjunction with its partner method will either move the
     * selected item to the trash, if the current working directory
     * IS NOT the TRASH CAN, or deletes forever if the selected item
     * is in the TRASH CAN.
     * 
     * Will recurse through an entire directory - just as would happen
     * in Windows and using rm -r in LINUX-like environments.
     * 
     */
    public function item_remove( Request $request ) {
        // Current Working Directory (cwd)
        $this->_alias_cwd( $request );
        $d = $this->ops_dir;
        $o = ( null !== $request->input( 'trash' ) ) ? urldecode( $request->input( 'trash' ) ) : null;
        if ( ! is_null( $o ) && ( ! is_null( $d ) && $d != $this->trash_dir ) ) {
            $trash = urldecode( $o );
            $path  = urldecode( $d );
            if ( $trash != '' ) {
                $rpth = $this->clean_string( $path . '/' . $trash );
                $this->thumbnail_cleanup_service( $rpth );
                $this->remove_empty_directory( $rpth );
            } else {
                $protocol = ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' );
                exit( "\r\nNeed to specify file or folder to remove.\r\n" );
            }
        }
        elseif ( ( isset( $o ) && ! is_null( $o ) ) && ( ! is_null( $d ) && $d == $this->trash_dir ) ) {
            $trash = urldecode( $o );
            $path  = urldecode( $d );
            $rpth = $this->clean_string( $path . '/' . $trash );
            $this->remove_r( $rpth );
        }
        return Redirect::back();
    }
    public function remove_empty_directory( $path ) {
        $trash   = $this->check_for_trash_folder();
        $file    = basename( urldecode( $path ) );
        $totrash = $trash . '/' . $file;
        $totrash = $this->iterate_filename( $file, $trash );
        if ( ! rename( $path, $totrash ) ) {
            echo "\r\nCould not TRASH the media item: $file.\r\n";
        }
        return Redirect::back();
    }
    public function remove_r( $path ) {
        if ( is_dir( $path ) ) {
            $objects = array_diff( scandir( $path ), [".",".."] );
            if ( sizeof( $objects ) > 0 ) {
                foreach( $objects as $file ) {
                    if ( is_dir( $path . $this->DS . $file ) ) {
                        $this->remove_r( $path . $this->DS . $file );
                    } else {
                        @unlink( $path . $this->DS . $file );
                    }
                }
            }
            reset( $objects );
            return rmdir( $path );
        } else {
            return unlink( $path );
        }
        return;
    }
    /**
     * Methods checks if a trash can exists wihtin the base
     * of the Filemanager media library folder:
     * eg. uploads/_trash.
     * 
     * If the directory exists than move on, otherwise it will
     * create one and then the path of the TRASH CAN created.
     * 
     */
    private function check_for_trash_folder() {
        $trash = $this->trash_dir;
        if ( ! file_exists( $trash ) ) {
            $old_mask = $this->_get_umask();
            @mkdir( $trash, 0755, true );
            $this->_get_umask( $old_mask );
        }
        return $trash;
    }
    /**
     * Thumbnail clean-up service
     * 
     * When removing media objects, which generate thumbnail content by
     * the FileManager, the generated thumbnails will not inherently be
     * removed - leaving a dirty working directory structure.
     * This is an attempt to clean-up FileManager thumbnails, thereby
     * not leaving any orphaned media object thumbnails.
     * 
     * input: path of the original object being removed;
     * return: none
     * 
     */
    private function thumbnail_cleanup_service( $p ) {
        $p = ltrim( $p, '/' );
        $thumbs = rtrim( $this->media_dir, '/' ) . '/' . 'media_thumbs' . '/' . $p;
        if ( file_exists( $thumbs ) ) {
            $this->remove_r( $thumbs );
        }
    }
    /**
     * Copy Backend Route Endpoint (see routes.php)
     *
     * Filemanager backend api endpoint for copying files
     * and/or folders to an EXISTING and PERMISSIBLE
     * destination folder/file.
     * 
     * globals: $_REQUEST and $_SERVER;
     * input: none; and
     * return: none (Redirects to the calling url).
     * 
     */
    public function item_copy( Request $request ) {
        // Current Working Directory (cwd)
        //$t = isset( $_REQUEST['folder'] ) ? urldecode( $_REQUEST['folder'] ) : null;
        $this->_alias_cwd( $request );
        $t = $this->ops_dir;
        $p =  $this->_get_public_path() . '/' . $this->media_dir . '/' . 'images';
        $s = preg_replace( '/\\\/', '/', $t . '/' . $request->input( 'src' ) );
        $d = $request->input( 'dst' ) . '/';
        if ( ( $s == $d ) || ! isset( $d ) || $d == '' ) return;
        if ( file_exists( $s ) && ( ! file_exists( $d ) || is_dir( $d ) ) ) {
            $this->copy_r( $s, $d );
        }
        return Redirect::back();
    }
    /**
     * Recursive Copy
     * 
     * Basic functionality is not to create empty directories that are present
     * in the source directory hierarchy. All other media objects are copied to
     * the destination file/folder, and nested within subdiretories as found
     * in the original source.
     * 
     * input: src file/folder and dst file/folder; and
     * return: true = copy success or false = copy failed.
     * 
     */
    public function copy_r( $path, $dest ) {
        if ( is_dir( $path ) ) {
            if ( is_dir( $dest ) ) {
                $dest .= $this->DS . basename( $path );
            }
            $dest = $this->iterate_filename( basename( $dest ), dirname( $dest ) );
            $this->make_directory( $dest );
            $objects = array_diff( scandir( $path ), [ ".", ".." ] );
            if ( sizeof( $objects ) > 0 ) {
                foreach( $objects as $file ) {
                    if ( is_dir( $path . $this->DS . $file ) ) {
                        $this->copy_r( $path . $this->DS . $file, $dest . $this->DS . $file );
                    } else {
                        $f = $path . $this->DS . $file;
                        $d = $this->iterate_filename( $file, $dest );
                        copy( $f, $d );
                    }
                }
            }
            return true;
        } elseif ( is_file( $path ) ) {
            if ( is_dir( $dest ) && file_exists( $dest ) ) {
                $dest .= $this->DS . basename( $path );
            } else {
                $dir = $dest;
                //dd( $dir );
                mkdir( $dir );
                $dest .= $this->DS . basename( $path );
            }
            $p = $this->iterate_filename( basename( $dest ), dirname( $dest ) );
            $dest = $p;
            if ( copy( $path, $dest ) ) {
                return true;
            }
        } else {
            return false;
        }
    }
    /**
     * Media Library Search
     * 
     * This method and its companion methods will provide searching
     * of the media library file structure hierarchy for the
     * specified supplied input pattern.
     * 
     * Results are filtered to prevent showing internal file structure.
     * See method (search_filter) below for details.
     * 
     */
    public function media_search( Request $request ) {
        $this->data['media_search'] = [];
        $this->_alias_cwd( $request );
        $folder = $this->ops_dir;
        // Current Working Directory (cwd)
        $folder = isset( $folder ) ? $this->clean_string( $folder )
                    : $this->media_dir . $this->DS . 'images' . $this->DS;
        $this->data['folder'] = $folder;
        $current_path = $folder . $this->DS . $this->clean_string( $request->input( 'search' ) );
        $file_objects = $this->glob_recursive( $current_path );
        $media_objects = array_filter( $file_objects, array( $this, "search_filter" ) );
        //dd( $media_objects );
        /*
        foreach( $media_objects as $file ) {
            $file = str_replace( '/.', '/', $file );
            array_push( $this->data['media_search'], 
                        $this->html_markup( $this->fs_obj_props( $file ) ) );
        }
        */
        $this->data['media_search'] = array_map(
            [ __CLASS__, 'fs_obj_props' ],
            array_filter(
                //$this->data['media_search'], array( $this, "search_filter" )
                $media_objects,  array( $this, "search_filter" )
            )
        );
        //dd( $this->data['media_search'] );
        session_start();
        $_SESSION['search'] = ( string ) $request->input( 'search' );// $_REQUEST['search'];
        $this->data['breadcrumbs']  = $this->breadcrumbs( $folder );
        //return view( 'monzamedia.vault_filemanager.listing', $this->data );
        return view( 'vaultfilemanager::vfm', $this->data );
    }
    /**
     * Filtering method which allows results to be excluded that come
     * from the TRASH CAN and MEDIA THUMBNAIL directories.
     * 
     * I.e. it prevents the searching of the "internal" FileManager
     * file structure hierarchy.
     * 
     */
    private function search_filter( $a ) {
        if ( ! preg_match( '/(\_trash|_thumb)/i', $a, $m ) ) {
            return $a;
        }
    }
    /**
     * Upload Media File
     * 
     * Handles media file uploads to the current working directory.
     * It will use the original client name as the filename.
     * 
     */
    public function media_upload( Request $request ) {
        // Current Working Directory (cwd)
        $this->_alias_cwd( $request );
        $folder = $this->ops_dir;
        $dir = $folder;//$_REQUEST['folder'];
        if ( $request->file( 'uploadFile' ) !== null ) {
            if ( $request->file( 'uploadFile' )->isValid() ) {
                $fileName = $request->file( 'uploadFile' )->getClientOriginalName();
                Input::file( 'uploadFile' )->move( $dir . "/", Input::file( 'uploadFile' )->getClientOriginalName() );
                $location = $dir . $this->DS . $fileName;
            } else {
                return false;
            }
        }
        return Redirect::back();
    }
    /**
     * SORTING nD Arrays by a specific column
     */
    function sortByString( $a, $b, $cn ) {
        $a = $a[$cn];
        $b = $b[$cn];

        if ( $a == $b ) return 0;
        return ( $a < $b ) ? -1 : 1;
    }
    function sortByNumber( $a, $b, $cn ) {
        $a = $a[$cn];
        $b = $b[$cn];

        if ( $a == $b ) return 0;
        return ( $a < $b ) ? -1 : 1;
    }

    /**
     * Create New Folder
     * 
     * Creates a new folder, which is named using the input supplied or
     * if no input supplied then defaults to New-Folder 
     * (as New Folder is despised).
     * 
     * Depending on the input supplied, the method will either
     * create the new directory in-situ or will create a new
     * directory recursively according to the input. The latter
     * will only occur if the permission is allowed along the 
     * entire path trajectory.
     * 
     * Recursive works from left-to-right.
     * 
     */
    public function media_create_directory( Request $request ) {
        $default  = 'New-Folder';
        $this->_alias_cwd( $request );
        $folder   = $this->ops_dir;
        $tmp      = $request->input( 'makedir' );
        $dir_name = ( isset( $tmp ) && ! empty( $tmp ) && ! is_null( $tmp ) && $tmp !== '' ) ? 
                        $tmp : $default;
        /*
        ( isset( $_REQUEST['makedir'] ) && ! empty( $_REQUEST['makedir'] ) &&
                        ! is_null( $_REQUEST['makedir'] ) && $_REQUEST['makedir'] !== '' ) 
                    ? $_REQUEST['makedir'] : $default;
        */
        // Current Working Directory (cwd)
        $path = ( isset( $folder ) ) ? $folder : null;
        if ( $this->make_directory( $dir_name, $path ) ) {
            return Redirect::back();
        }
    }
    private function make_directory( $name='New-Folder', $path=null ) {
        $dir_perms = 0777;
        if ( is_null( $path ) ) $path = '.';
        $path = rtrim( $path, '/' );
        $name = ltrim( $name, '/' );
        $old_mask = $this->_get_umask();
        $fullpath = $path . '/' . $name;
        if ( file_exists( $fullpath ) ) {
            $n = 0;
            $fullpath = $fullpath . "-$n";
            while( file_exists( $fullpath ) && ( $n < 100 ) ) {
                $m = $n + 1;
                $fullpath = preg_replace( "/\d+$/", $m, $fullpath );
                $n++;
            }
            echo '<h1>Directory Already Exists</h1>';
        }
        if ( ! mkdir( $fullpath, $dir_perms, true ) ) {
            echo 'Failed to create folders...';
            return false;
        }
        umask( $old_mask );
        return true;
    }
    /**
     * NOT THREAD SAFE
     * 
     * Supplies the umask if no input supplied or
     * sets the umask if a valied input is supplied.
     * 
     * Correct php code for setting new mask, with
     * cmask = 0700 and umask = 0022:
     * 
     *  $rmask = ($cmask & ~$umask);
     *
     */
    private function _get_umask( $v=null ) {
        return ( isset( $v ) || is_null( $v ) ) ? umask( 0 ) : umask( $v );
    }
    private function _set_umask( $v=null ) {

    }
    private function _print_umask( $m ) {
        if ( ! isset( $m ) || null == $m ) return false;
        echo "<code>\r\nCurrent umask value: " . decoct( $umask ) . "\r\n</code>";
    }
    private function listFiles( $from = '.', $excludes=null, $walk='walk' ) {
        if( ! is_dir( $from ) ) return false;
        $excl = ( ! is_null( $excludes ) ) ? ( is_array( $excludes ) ) 
                    ? implode( '|', $excludes ) : ( string ) $excludes : 
                        null;
        $files = array();
        $dirs  = array( $from );
        if ( $walk == 'nowalk' ) {
            $dir = array_pop( $dirs );
            if ( $dh = opendir( $dir ) ) {
                while ( false !== ( $file = readdir( $dh ) ) ) {
                    if ( $file == '.' || $file == '..') continue;
                    if ( ! preg_match( "/($excl)/i", $file, $m ) ) {
                        $dir     = preg_replace( "/\/?$/", "", $dir );
                        $path    = $dir . '/' . $file;
                        $files[] = $path;
                    } else { 
                         continue;
                    }
                }
                closedir($dh);
            }
        } else {
            while( NULL !== ( $dir = array_pop( $dirs ) ) ) {
                if( $dh = opendir( $dir ) ) {
                    while( false !== ( $file = readdir( $dh ) ) ) {
                        if( $file == '.' || $file == '..')
                            continue;
                        if ( ! preg_match( "/($excl)/i", $file, $m) ) {
                            $dir = preg_replace( "/\/?$/", "", $dir );
                            $path = $dir . '/' . $file;
                            if( is_dir($path) )
                                $dirs[] = $path;
                            else
                                $files[] = $path;
                        } else { 
                             continue;
                        }
                    }
                    closedir($dh);
                }
            }    
        }
        return $files;
    }
    /**
     * Creates a tree-structured array of directories and files from a given root folder.
     *
     * Gleaned from: http://stackoverflow.com/questions/952263/deep-recursive-array-of-directory-structure-in-php
     *
     * @param string $dir
     * @param string $regex
     * @param boolean $ignoreEmpty Do not add empty directories to the tree
     * @return array
     */
    private function dirtree( $dir, $rtnwhat='all', $regex='', $ignoreEmpty=false ) {
        if ( ! $dir instanceof DirectoryIterator ) {
            $dir = new DirectoryIterator( ( string )$dir );
        }
        $dirs = $files = array();
        foreach ($dir as $node) {
            if ( $node->isDir() && !$node->isDot() ) {
                $tree = dirtree( $node->getPathname(), $regex, $ignoreEmpty );
                if ( ! $ignoreEmpty || count( $tree ) ) {
                    $dirs[$node->getFilename()] = $tree;
                }
            } elseif ( $node->isFile() ) {
                $name = $node->getFilename();
                if ( '' == $regex || preg_match( $regex, $name ) ) {
                    $files[] = $name;
                }
            }
        }
        asort( $dirs ); sort( $files );
        if ( $rtnwhat == 'files' ) {
            return $files;
        } else if ( $rtnwhat == 'dirs' || $rtnwhat == 'folders' ) {
            return $dirs;
        } else {
            return array_merge($dirs, $files);
        }
    }
    private function createThumbnail( $pathToImage, $dest, $thumbWidth=120 ) {
        $result = 'Failed';
        if ( is_file( $pathToImage ) ) {
                $info = pathinfo( $pathToImage );
                $extension = strtolower( $info['extension'] );
                if ( in_array( $extension, array( 'jpg', 'jpeg', 'png', 'gif') ) ) {
                    switch ( $extension ) {
                        case 'jpg':
                            try {
                                $img = imagecreatefromjpeg( "{$pathToImage}" );
                                break;
                            } catch ( Exception $e ) { /* $err = $e*/ }
                        case 'jpeg':
                            try {
                                $img = imagecreatefromjpeg("{$pathToImage}");
                                break;
                            } catch ( Exception $e ) { /* $err = $e*/ }
                        case 'png':
                            try {
                                $img = imagecreatefrompng("{$pathToImage}");
                                break;
                            } catch ( Exception $e ) { /* $err = $e*/ }
                        case 'gif':
                            try {
                                $img = imagecreatefromgif("{$pathToImage}");
                                break;
                            } catch ( Exception $e ) { /* $err = $e*/ }
                        default:
                            try {
                                $img = imagecreatefromjpeg("{$pathToImage}");
                                break;
                            } catch ( Exception $e ) { /* $err = $e*/ }
                    }
                    // load image and get image size
                    $width  = imagesx( $img );
                    $height = imagesy( $img );
                    $aspect = $height / $width;
                    // calculate thumbnail size
                    $new_width  = $thumbWidth;
                    $new_height = $new_width * $aspect;
                    // create a new temporary image
                    $tmp_img = imagecreatetruecolor($new_width, $new_height);
                    // copy and resize old image into new image
                    imagecopyresized($tmp_img, $img, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
                    //$pathToImage = $pathToImage . '.thumb.' . $extension;
                    // save thumbnail into a file
                    switch ( $extension ) {
                        case 'jpg':
                            try {
                                imagejpeg( $tmp_img, $dest );
                                break;
                            } catch( Exception $e ) { /**/ }
                        case 'jpeg':
                            try {
                                imagejpeg( $tmp_img, $dest );
                                break;
                            } catch( Exception $e ) { /**/ }
                        case 'png':
                            try {
                                imagepng( $tmp_img, $dest );
                                break;
                            } catch( Exception $e ) { /**/ }
                        case 'gif':
                            try {
                                imagegif( $tmp_img, $dest );
                                break;
                            } catch( Exception $e ) { /**/ }
                        default:
                            try {
                                imagejpeg( $tmp_img, $dest );
                                break;
                            } catch( Exception $e ) { /**/ }
                    }
                    //imagejpeg($tmp_img, $dest);//"{$pathToImage}");
                    $result = $dest; // $pathToImage;
                } else {
                    $result = 'Failed | Not an accepted image type (JPG, PNG, GIF).';
                }
        } else {
            $result = 'Failed | Image file does not exist.';
        }
        return $result;
    }
    private function directory_item_count( $path=null, $wrcn=0 ) {
        $nitm = 0;
        if ( ! isset( $path ) || is_null( $path ) ) return;
        if ( ! file_exists( $path ) && (  ! is_dir( $path ) ) ) {
            return;
        } else {
            $results  = scandir( $path );
            $contents = array_diff( $results, [ '.', '..' ] );
            $nitm = count( $contents );
        }
        return $nitm;
    }
    private function get_pathinfo( $p=null ) {
        if ( ! isset( $p ) || is_null( $p ) || $p == '' ) return;
        if ( check_path( $p ) ) {
            $tmp = pathinfo( $p );
            $rtn = [
                'dirname'  => $tmp['dirname'],
                'filename' => $tmp['filename'],
                'extension'=> $tmp['extension'],
                'basename' => $tmp['basename'],
            ];
            unset( $tmp );
            return $rtn;
        } else {
            /* Exception */
            $err_msg  = 'Unable to get the pathinfo for the Object: ';
            $err_msg .= basename( $p ) . '.';
            return $err_msg;
        }
    }

    private function get_stats( $f=null ) {
        clearstatcache( );
        $ss = @stat( $f );
        //Couldnt stat file - so return false
        if ( ! $ss ) return false;
        $ftime = [
            'atime'  => $ss['atime'],
            'mtime'  => $ss['mtime'],
            'ctime'  => $ss['ctime'],
            'access' => @date('Y-m-d H:i',$ss['atime'] ),//@date('D, d M Y @ H:i',$ss['atime'] ),
            'modify' => @date('Y-m-d H:i',$ss['mtime'] ),//@date('D, d M Y @ H:i',$ss['mtime'] ),
            'create' => @date('Y-m-d H:i',$ss['ctime'] ),//@date('D, d M Y @ H:i',$ss['ctime'] ),
        ]; 
        $fsize = [
            'size' =>    $ss['size'], //Size of file, in bytes.
            'blck' =>  $ss['blocks'], //Number 512-byte blocks allocated
            'bsze' => $ss['blksize'], //Optimal block size for I/O.
        ];
        return array_merge( $ftime, $fsize );
    }
    private function size_human( $bytes=0 ) {
        $units = [ 'B', 'KB', 'MB', 'GB', 'TB', 'PB', ];
        $base = $bytes ? floor( log10( $bytes ) / log10( 1024 ) ) : 0;
        $size = round( ( $bytes / pow( 1024, floor( $base ) ) ), 2 );
        $sunt = $units[$base];
        return sprintf( '%.2f' . ' ' . $sunt, $size );
    }
    private function urlify_filenames( $n, $u='htmlsp' ) {
        $tmp = preg_replace( '/\s+/i', '%20', $n );
        switch( $u ) {
            case 'htmlen':
                $tmp = htmlentities( $tmp, ENT_QUOTES, 'UTF-8' );
                break;
            default:
                $tmp = htmlspecialchars( $tmp, ENT_QUOTES, 'UTF-8' );
                break;
        }
        return $this->chop_string( $tmp, 20 );
    }
    private function show_relpath( $pth ) {
        $tmp = ( string ) realpath( $_SERVER['DOCUMENT_ROOT'] );
        //$doc_root = preg_replace( '/\\\/i', '\/', $tmp );
        $doc_root = str_replace( '\\', '\/', $tmp );
        //echo( $doc_root );
        //dd( str_replace( "/" . ( string ) $doc_root . "\/?/i", "", $pth ) );
        unset( $tmp );
        return str_replace( "/" . ( string ) $doc_root . "\/?/i", "", $pth );
    }
    private function get_strlen( $str ) {
        return strlen( $str );
    }
    private function chop_string( $str, $fs=14, $max=260 ) {
        $sl = ( int ) $this->get_strlen( $str );
        $cm = ( int ) floor( $max / $fs ) + 3;
        $arr = [];
        if ( $sl > $cm ) {
            $dv = ( int ) ceil( $sl - $cm );
            array_push( $arr, substr( $str, 0, ( ($cm / 2) - 1 ) ) );
            array_push( $arr, '...' );
            array_push( $arr, substr( $str, $dv + ( ( $cm /2 ) + 2 ) ) );
        } else {
            $arr[] = $str;
        }
        return implode( '', $arr );
    }
    private function glob_recursive( $pattern, $flags=0 ) {
        $files = glob( $pattern, $flags );
        foreach ( glob( dirname( $pattern ) . '/*',
                  GLOB_ONLYDIR|GLOB_NOSORT ) as $dir ) {
            $files = array_merge(
                $files, $this->glob_recursive( $dir . '/' . basename( $pattern ), $flags )
            );
        }
        return $files;
    }
    private function php_file_tree( $directory, $return_link='', $extensions=array()) {
        // Generates a valid XHTML list of all directories, sub-directories, and files in $directory
        $code = '';
        // Remove trailing slash
        if ( substr( $directory, -1 ) == "/" ) {
            $directory = substr( $directory, 0, strlen( $directory ) - 1 );
        }
        $code .= php_file_tree_dir( $directory, $return_link, $extensions );
        return $code;
    }
    private function php_file_tree_dir( $directory, $return_link='', $extensions=array(), $first_call=true) {
        // Recursive function called by php_file_tree() to list directories/files
        $php_file_tree = '';
        // Get and sort directories/files
            $file = ( function_exists( "scandir" ) ) ? scandir( $directory ) : 
                                            $this->php4_scandir( $directory );
        natcasesort( $file );
        // Make directories first
        $files = $dirs = array();
        foreach( $file as $this_file ) {
            if ( is_dir( "$directory/$this_file" ) ) {
                $dirs[] = $this_file;
            } else {
                $files[] = $this_file;
            }
        }
        // Filter unwanted extensions
        if( ! empty( $extensions ) ) {
            foreach( array_keys( $file ) as $key ) {
                if( ! is_dir( "$directory/$file[$key]" ) ) {
                    $ext = substr( $file[$key], strrpos( $file[$key], "." ) + 1 ); 
                    if( ! in_array( $ext, $extensions ) ) unset( $file[$key] );
                }
            }
        }
        // Filter unwanted directories (HARDCODED: media_thumbs && _trash)
        foreach( $file as $k=>$dir ) {
            if ( preg_match( '/(media_thumbs|_trash)/i', $dir, $m ) ) {
                unset( $file[$k] );
            }
        }
        // Use 2 instead of 0 to account for . and .. "directories" <-- dealt with using array_diff
        if ( count( $file ) > 0 ) {
            $php_file_tree = "<ul";
            if ( $first_call ) {
                $php_file_tree .= " class=\"php-file-tree\""; $first_call = false;
            }
            $php_file_tree .= ">";
            $file = array_diff( $file, [ '.', '..' ] );
            foreach( $file as $this_file ) {
                if ( is_dir( "$directory/$this_file" ) ) {
                    // Directory
                    $d = "$directory/$this_file";
                    //$php_file_tree .= "<li class=\"pft-directory\"><a href=\"\" title=\"" . htmlspecialchars($this_file) . "\" data-folder-target=\"$directory/$this_file\" onmousedown=\"window.tgtFolder=(this.classList.contains('closed')) ? this.getAttribute( 'data-folder-target' ): null; document.querySelector('#selected_folder textarea').innerHTML = tgtFolder;\">" . htmlspecialchars($this_file) . "</a>";
                    // onchange=\"window.tgtFolder=( this.value ) ? this.value: null; document.querySelector('input[name=folder].dest-dir').value = tgtFolder;\"
                    $php_file_tree .= "<li class=\"pft-directory\"><label><input type=\"radio\" name=\"folder\" value=\"$d\">" . htmlspecialchars($this_file) . "</label>";
                    $php_file_tree .= $this->php_file_tree_dir( "$directory/$this_file", $return_link , $extensions, false );
                    $php_file_tree .= "</li>";
                    //$php_file_tree .= "</label></li>";
                }/* else {//if ( is_file( "$directory/$this_file" ) && ( $listwhat === 'all' || $listwhat === 'file' ) ) {
                    // File
                    // Get extension (prepend 'ext-' to prevent invalid classes from extensions that begin with numbers)
                    $ext = "ext-" . substr($this_file, strrpos($this_file, ".") + 1); 
                    $link = str_replace("[link]", "$directory/" . urlencode($this_file), $return_link);
                    $php_file_tree .= "<li class=\"pft-file " . strtolower($ext) . "\"><a href=\"$link\">" . htmlspecialchars($this_file) . "</a></li>";
                }*/
            }
            $php_file_tree .= "</ul>";
        }
        return $php_file_tree;
    }
    // For PHP4 compatibility
    private function php4_scandir( $dir ) {
        $dh  = opendir( $dir );
        while( false !== ($filename = readdir( $dh ) ) ) {
            $files[] = $filename;
        }
        sort( $files );
        return( $files );
    }
    /**
    * BREADCRUMBS
    *
    * BS 4 Breadcrumbs template
    * 
    * <ol|ul class="breadcrumb">
    *  <li class="breadcrumb-item"><a href="#">Home</a></li>
    *  <li class="breadcrumb-item"><a href="#">Library</a></li>
    *  <li class="breadcrumb-item active">Data</li>
    * </ol|ul>
    * 
    */
    private function breadcrumbs( $path_inp='uploads/images', $prev_crumbs=[], $sep='<i class="fa fa-caret-right p-fafa-breadcrumb"></i>', $home='home' ) {
        $bc      = '<ul class="breadcrumb">';
        $site    = 'http://'.$_SERVER['HTTP_HOST'] . '/home/vaultfilemanager/';
        $req_uri = ( isset($path_inp) || ! is_null($path_inp) ) ? $path_inp : $_SERVER["REQUEST_URI"];
        $req_uri = urldecode( htmlspecialchars_decode( $req_uri ) );
        $path    = preg_replace( "/(\w+)\/\?\w+=/i", "", $req_uri );
        $crumbs  = ( $path !== '/' ) ? array_filter( explode( "/", $path ) ) : array();
        //if ( is_null( $path ) ) echo $path; //print_r( (bool)$crumbs[0], $path );
        $nm = ( int ) count( $crumbs );
        if ( $nm === 0 || $path === '' ) {
            $sep = '';
            $site = '/';//.VFM_BASEDIR;
            $bc .=   '<li class="breadcrumb-item"><a href="' . $site . '">' . $home . '</a>' . $sep . '</li>';
            $bc .=  '</ul>';
            return $bc;
        } else {
            $bc .=   '<li class="breadcrumb-item"><a href="' . $site . '">' . $home . '</a>' . $sep . '</li>';
        }
        $i = ( int ) 1;                 //Skip first crumb, which is home
        $last_piece = end( $crumbs );   //grab the last crumb
        foreach( $crumbs as $crumb ){   //Loop through the crumbs
            //Make the link look nice && Loose the last seperator
            $link = str_replace( array( ".php" ), array( "" ), $crumb );
            //ucfirst( str_replace( array( ".php" ), array( "" ), $crumb ) );
            $sep = ( $i === $nm ) ? '': $sep;
            //Add crumbs to the root
            /*
            if ( ! preg_match( '/\?folder/i', $site, $m ) ) {
                $site .= '?folder=' . $crumb;
            } else {
                $site .= '/' . $crumb;
            }
            */
            $site .= ( ! preg_match( '/\?folder/i', $site, $m ) ) ? '?folder=' . $crumb: '/' . $crumb;
            //Check if last crumb by index
            /*
            if ( $i !== $nm ) {// && $crumb !== $last_piece ) {
                //Last crumb, do not make it a link
                $bc .= '<li class="breadcrumb-item"><a href="' . $site  .'">' . $link . '</a>' . $sep . '</li>';
            } else {
                //Make the next crumb
                $bc .= '<li class="breadcrumb-item active">' .
                    //ucfirst( str_replace( array( ".php" ), array( "" ), $last_piece ) ) .
                    str_replace( array( ".php" ), array( "" ), $last_piece ) .
                '</li>';
            }
            */
            $bc .= ( $i !== $nm ) ? 
                    '<li class="breadcrumb-item"><a href="' . $site  .'">' . $link . '</a>' . $sep . '</li>'
                    : '<li class="breadcrumb-item active">' .
                    //ucfirst( str_replace( array( ".php" ), array( "" ), $last_piece ) ) .
                    str_replace( array( ".php" ), array( "" ), $last_piece ) .
                '</li>';
            $i++;
        }
        $bc .= '</ul>';
        return $bc;
    }
    /**
     * Simple Archiving Function using gzip
     * 
     * Public function for usage by the backend and frontend user.
     * 
     */
    public function archive_container( Request $request ) {
    }
    /**
     * Force a file download
     */
    public function forceDownload( $file ) {
        if ( ( isset( $file ) ) && ( file_exists( $file ) ) ) {
            header( "Content-length: " . filesize( $file ) );
            header( 'Content-Type: application/octet-stream' );
            header( 'Content-Disposition: attachment; filename="' . $file . '"' );
            readfile( "$file" );
        } else {
            echo "No file selected";
        }
    }
    /**
     * Get IP Address
     */
    private function getRealIPAddr() {
         if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
            //check ip from share internet
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            //to check ip is pass from proxy
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }

}
