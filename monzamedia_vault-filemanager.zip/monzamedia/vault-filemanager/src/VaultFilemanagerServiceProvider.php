<?php namespace Monzamedia\VaultFilemanager;

use Illuminate\Support\ServiceProvider;

class VaultFilemanagerServiceProvider extends ServiceProvider {
/**
 * Publish public assets such as css, js and helper images to:
 * --->
 *  /public/assets/(css|js|images)/...[/asset_parent_folder]
 * 
 */
    protected $view_dest   = '/resources/views/vault/monzamedia/vault-filemanager';
    protected $css_dest    = '/assets/css';
    protected $js_dest     = '/assets/js';
    protected $images_dest = '/assets/images';
    protected $config_src  = 'vault-filemanager_image_types.php';
    protected $helper_fncs = __DIR__ . '/support/vfm_render_inc.php';
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot() {
        /**
         * Publishing Migrations
         */
        //$this->publishes( [
        //    __DIR__ . '/migrations' => $this->app->databasePath() . '/migrations'
        //], 'migrations' );
        /**
         * Publishing Views
         */
        $this->publishViews( $this->view_dest ); //resources/views/vault/monzamedia/vault-filemanager' );
        /**
         * Publishing CSS, JS, IMAGES and Helper Images
         */
        $this->publishes( [
            __DIR__ . $this->css_dest => public_path( $this->css_dest )
        ], 'css' );
        $this->publishes( [
            __DIR__ . $this->js_dest => public_path( $this->js_dest )
        ], 'js' );
        $this->publishes( [
            __DIR__ . $this->images_dest => public_path( $this->images_dest )
        ], 'images' );
        /**
         * Publishing Config
         */
        $this->publishConfig( $this->config_src );
        /**
         * Publishing Routes
         */
        //$this->publishRoutes( $this->route_src );
        /**
         * Load up the helper functions file
         */
        $this->loadHelpers();

        return;
    }
    /**
     * Register the application services.
     *
     * @return void
     */
    public function register() {
        /*
        // Merge Config
        *//*
        $i = __DIR__ . '/../config/vault-filemanager_image_types.php';
        $o = 'vault-filemanager_image_types.php';
        */
        //$this->mergeConfigFrom( $i, $o );
        /*
        // Route(s)
        */
        $this->loadRoutesFrom( __DIR__ . '/routes/web.php' );
        /*
        // View(s)
        */
        $this->loadViewsFrom( __DIR__ . '/Views', 'vaultfilemanager' );
        /*
        // Alias(es)
        */
        //$this->app->alias( VaultFilemanagerController::class, 'vault-filemanager' );
        /*
        // Controller(s)
        */
        //$this->app->make( 'Monzamedia\VaultFilemanager\VaultFilemanagerController' );
        /*
        // Singleton(s)
        */
        $this->app->singleton(
            VaultFilemanagerController::class, function () {
                return new VaultFilemanagerController();
            }
        );
    }

    /**
     * Load the Backpack helper methods, for convenience.
     */
    private function loadHelpers() {
        return require_once $this->helper_fncs;
    }
    /**
     * Publish Package Assets (separately for CSS, JS and IMAGES)
     */
    private function publishAssets( $atype, $from, $publish_to ) {
        if ( is_dir( __DIR__ . $from ) ) {
            $this->publishes( [
                __DIR__ . $from => public_path( $publish_to )
            ], $atype );
        }
        return;
    }
    /**
     * Publish Package Config
     */
    private function publishConfig( $publish_to ) {
        if ( is_dir( __DIR__ . '/config' ) ) {
            $this->publishes( [
                __DIR__ . '/config/vault-filemanager_image_types.php' => 
                config_path( $publish_to )
            ], 'config' );
        }
        return;
    }
    /**
     * Publish Package Views
     */
    private function publishViews( $publish_to ) {
        if ( is_dir( __DIR__ . '/Views' ) ) {
            $this->publishes( [
                __DIR__ . '/Views' => base_path( $publish_to )
            ], 'views' );
        }
        return;
    }
    /**
     * Publish Package Routes
     */
    private function publishRoutes( $publish_to ) {
        if ( is_dir( __DIR__ . '/migrations' ) ) {
            $this->publishes( [
                __DIR__ . '/migrations' =>
                $this->app->databasePath() . '/' . $publish_to
            ], 'migrations' );
        }
        return;
    }
}
