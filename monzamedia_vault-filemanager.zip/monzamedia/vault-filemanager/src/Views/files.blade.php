
<div class="media-item">
    <div class="padme">
        <div id="{{ hash('whirlpool', (urlencode( $media_item['name'] ))) }}" class="media-card-container dshadow1">
            <div class="item-type-image">
                <img src="http://via.placeholder.com/120x80" class="lazy image center-center mm-ml-tn img-thumb" data-src="/uploads/media_thumbs/{{ $media_item['path'] }}/{{ $media_item['name'] }}" alt="file=>type:jpg;name:home-banner.jpg" data-source="/{{ $media_item['path'] }}/{{ $media_item['name'] }}">
            </div><!--/ .item-type-folder||.item-type-file -->
            <div class="metadata">
                <div class="item-name">
                    <h2><abbr title="/{{ $media_item['path'] }}/{{ $media_item['name'] }}">{{ $media_item['display_name'] }}</abbr></h2>
                </div>
                <div class="item-size-count">
                    <p>
                        <!--90.24 KB-->
                        {{ $media_item['szcnt']['human'] }}
                    </p>
                </div>
                <div class="item-last-modified">
                    <p>
                        <!--2018-08-20 16:05-->
                        {{ $media_item['stats']['modify'] }}
                    </p>
                </div>
            </div><!--/ .metadata -->
            <div class="media-item-actions-container">
                <form class="media-item-action edit" id="edit" method="POST" action="vaultfilemanager/rename" onsubmit="event.preventDefault();">
                    @csrf
                    <input type="hidden" name="folder" value="{{ $media_item['path'] }}">
                    <input type="hidden" name="ifile" value="{{ $media_item['name'] }}">
                    <input type="hidden" name="ofile">
                    <button class="action-icons center-center" type="submit" id="rename-image" onclick="m.edit( event );">
                        <img src="/assets/images/helper_icons/icons/edit.svg">
                    </button>
                </form>
                <!--div class="media-item-action download"-->
                    <a class="media-item-action download" title="Media Object Download" href="../{{ $media_item['path'] }}/{{ $media_item['name'] }}" download="">
                        <img class="action-icons center-center" src="/assets/images/helper_icons/icons/download.svg">
                    </a>
                <!--/div-->
                <form class="media-item-action copy" id="copy" method="POST" action="vaultfilemanager/copy">
                    @csrf
                    <input type="hidden" name="folder" value="{{ $media_item['path'] }}">
                    <input type="hidden" name="src" value="{{ $media_item['name'] }}">
                    <input type="hidden" name="dst">
                    <button type="submit" class="action-icons center-center" id="copy-image" onclick="m.copy( event, this );">
                        <img src="/assets/images/helper_icons/icons/copy.svg">
                    </button>
                </form>
                <form class="media-item-action link" id="link" method="" action="">
                    @csrf
                    <input type="hidden" name="folder" value="{{ $media_item['path'] }}">
                    <input id="the-link" type="hidden" name="link" value="{{ $media_item['path'] }}/{{ $media_item['name'] }}">
                    <button type="submit" class="action-icons center-center" id="link-image" data-target="#get-link-modal" data-toggle="hidden" onclick="event.preventDefault(); get_link( event, this );">
                        <img src="/assets/images/helper_icons/icons/link.svg">
                    </button>
                </form>
                <form class="media-item-action delete" id="delete" method="POST" data="jpg" action="vaultfilemanager/trash">
                    @csrf
                    <input type="hidden" name="folder" value="{{ $media_item['name'] }}">
                    <input type="hidden" name="trash" value="{{ $media_item['name'] }}">
                    <button type="submit" class="action-icons center-center" id="trash-image" onclick="m.remove( event, this );">
                        <img src="/assets/images/helper_icons/icons/trash.svg">
                    </button>
                </form>
            </div><!--/ .media-item-actions-container -->
        </div><!--/ .media-item-container -->
    </div>    
</div>
