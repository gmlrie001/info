
{{-- dd( $media_item, $folder ) --}}
<div class="media-item">
    <div id="{{ hash('whirlpool', (urlencode( $media_item['name'] ))) }}" class="media-card-container dshadow1">
        <div class="item-type-folder">
            <a class="padme" title="Folder" href="?folder={{ $media_item['path'] }}/{{ $media_item['name'] }}">
                <img data-folder="{{ $folder }}" src="/assets/images/filemanager/icons/svg/file_folder_icon.svg" class="lazy folder mm-ml-icon img-thumb center-center" data-src="/assets/images/filemanager/icons/svg/file_folder_icon.svg" alt="Folder">
            </a>
        </div><!--/ .item-type-folder||.item-type-file -->
        <div class="metadata">
            <a class="padme" title="Folder" href="?folder={{ $media_item['path'] }}/{{ $media_item['name'] }}">
                <div class="item-name">
                    <h2><abbr title="/{{ $media_item['path'] }}/{{ $media_item['name'] }}">{{ $media_item['display_name'] }}</abbr></h2>
                </div>
                <div class="item-size-count">
                    <p><abbr title="Folder Item Count">{{ $media_item['szcnt']['items'] }}</abbr> Items</p>
                </div>
                <div class="item-last-modified">
                    <p>{{ $media_item['stats']['modify'] }}</p>
                </div>
            </a><!-- padme anchor-link tag -->
        </div><!--/ .metadata -->
        <div class="media-item-actions-container">
            <form class="media-item-action edit" id="edit" method="POST" action="vaultfilemanager/rename" onsubmit="event.preventDefault();">
                @csrf
                <input type="hidden" name="folder" value="{{ $media_item['path'] }}">
                <input type="hidden" name="ifile" value="{{ $media_item['name'] }}">
                <input type="hidden" name="ofile">
                <button class="action-icons center-center" type="submit" id="rename-image" onclick="m.edit( event );">
                    <img src="/assets/images/helper_icons/icons/edit.svg">
                </button>
            </form>
            <div class="media-item-action open-folder">
                <a class="padme" title="Folder" href="?folder={{ $media_item['path'] }}/{{ $media_item['name'] }}">
                    <i class="fa fa-folder-open-o action-icons center-center"></i>
                </a>
            </div>
            <form class="media-item-action copy" id="copy" method="POST" action="vaultfilemanager/copy">
                @csrf
                <input type="hidden" name="folder" value="{{ $media_item['path'] }}">
                <input type="hidden" name="src" value="{{ $media_item['name'] }}">
                <input type="hidden" name="dst">
                <button type="submit" class="action-icons center-center" id="copy-image" onclick="m.copy( event, this );">
                <img src="/assets/images/helper_icons/icons/copy.svg">
                </button>
            </form>
            <form class="media-item-action link" id="link" method="" action="">
                @csrf
                <input type="hidden" name="folder" value="{{ $media_item['path'] }}">
                <input id="the-link" type="hidden" name="link" value="/{{ $media_item['path'] }}/{{ $media_item['name'] }}">
                <button type="submit" class="action-icons center-center" id="link-image" data-target="#get-link-modal" data-toggle="hidden" onclick="event.preventDefault(); get_link( event, this );">
                <img src="/assets/images/helper_icons/icons/link.svg">
                </button>
            </form>
            <form class="media-item-action delete" id="delete" method="POST" data="folder" action="vaultfilemanager/trash">
                <input type="hidden" name="_token" value="I0g0rluqniKwppS5UIwk7G7erGb5PADjwfxZ2d2v">
                <input type="hidden" name="folder" value="{{ $media_item['path'] }}">
                <input type="hidden" name="trash" value="{{ $media_item['name'] }}">
                <button type="submit" class="action-icons center-center" id="trash-image" onclick="m.remove( event, this );">
                    <img src="/assets/images/helper_icons/icons/trash.svg">
                </button>
            </form>
        </div><!--/ .media-item-actions-container -->
    </div><!--/ .media-item-container -->
</div>
