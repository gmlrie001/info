    <!--Front-End Scripts-->
    <script src="{{ asset('/assets/js/vault/scripts.js') }}" type="text/javascript"></script>

    <!-- FileManager JS Scripts -->
    <script src="{{ asset('/assets/js/filemanager/main.js') }}" type="text/javascript"></script>
    <script src="{{ asset('/assets/js/filemanager/php_file_tree.js') }}" type="text/javascript"></script>

    <script id="filemanager-styles" type="text/javascript">
        document.documentElement.style.overflow = 'hidden';
        fm_id = document.querySelector( '#filemanager' );
        //fm_id.classList.toggle( 'hidden' );
        window.addEventListener( 'load', function() {
            fid = fm_id;
            fm_css = '/assets/css/vault/filemanager.css',
            doc_head   = document.head,
            lnk = document.createElement( 'link' );
            // Setup the necessary attributes on the link tag
            lnk.type = 'text/css';
            lnk.rel  = 'stylesheet';
            lnk.href = fm_css;
            doc_head.appendChild( lnk );
            // INJECT into document head
            try {
                setTimeout( function() {
                    try {
                        document.querySelector( '#fm.loader' ).classList.toggle( 'hidden' );
                        /*fid.classList.remove( 'hidden' );*/
                    } catch( e ) {
                        console.warn( "\r\n" + e + "\r\n" );
                    }
                }, 400 );
                /*
                setTimeout( function() {
                    try {
                        if ( fid.classList.contains( 'hidden' ) ) {
                            fid.classList.remove( 'hidden' );
                        }
                    } catch( e ) {
                        console.warn( "\r\n" + e + "\r\n" );
                    }
                }, 500 );
                */
            } catch( e ) {
                console.warn( "\r\n" + e + "\r\n" );
            }
            document.documentElement.style.overflow = '';
            fid.classList.toggle( 'hidden' );
        }, false );
        //window.removeEventListener( 'load', function() { }, false );
    </script>

    <script>
    try {
        // Get the modal
        modal = document.querySelector('#image-view.modal-container'),
        content   = document.querySelector('#image-view.modal-container .modal-content .image-container'),
        // Get the button that opens the modal
        btns      = document.querySelectorAll(".img-thumb"),//[0];
        // Get the <span> element that closes the modal
        span      = document.querySelector("#image-view .modal-close");

        for( var n=0; n<btns.length; n++ ) {
            var btn = btns[n];
            // When the user clicks on the button, open the modal 
            btns[n].onclick = function() {
                if ( this.hasAttribute( 'data-source' ) ) {
                    var img_dims  = {},
                        img_style,
                    img_cont_dims = {'w':960,'h':640,};
                    var src = this.getAttribute( 'data-source' ),
                        tex = src.split( '.' ),
                        ext = tex[tex.length - 1];
                    full_img = document.createElement( 'img' );
                    /* Set image attributes etc. and then append to DOM element */
                    full_img.src = src; //http://placehold.it/360x540
                    full_img.alt = 'Image Preview';
                    full_img.classList.add( 'img-center' );
                    full_img.classList.add( 'img-fluid' );
                    full_img.classList.add( 'animated' );
                    full_img.classList.add( 'hidden' );
                    if ( src.search( 'svg' ) != -1 ) {
                        full_img.classList.add( 'img-svg' );
                    }
                    //content.innerHTML = "<span class='pull-right modal-close'>&times;</span>";
                    content.appendChild( full_img );
                    modal.classList.toggle( 'hidden' );
                    /* Set image dimensions in styling string */
                    setTimeout( function(){
                        var w, h, f,
                        nw = full_img.naturalWidth,
                        nh = full_img.naturalHeight;
                        if ( nw>=img_cont_dims.w || nh>=img_cont_dims.h ) {
                            f = ( nw>=img_cont_dims.w ) ? img_cont_dims.w/nw : 1;
                            w = full_img.naturalWidth  * f;
                            f = ( nh>=img_cont_dims.h ) ? img_cont_dims.h/nh : 1;
                            h = full_img.naturalHeight * f;
                        }
                        else {
                            w =  full_img.naturalWidth;
                            h = full_img.naturalHeight;
                        }
                        img_dims  = {
                            'w': w,
                            'h': h,
                        };
                        img_style = "width:"+img_dims.w+"px !important;height:"+img_dims.h+"px!important;";
                        /*
                        console.log( (full_img.naturalWidth>=window.innerWidth) ? full_img.naturalWidth*0.33333 : full_img.naturalWidth );
                        console.log( (full_img.naturalHeight>=window.innerHeight) ? full_img.naturalHeight*0.33333 : full_img.naturalHeight );
                        */
                        full_img.setAttribute( 'style', img_style );
                        full_img.classList.toggle( 'hidden' );
                        full_img.classList.toggle( 'fadeIn' );
                    },250);
                } else {
                    var src = this.getAttribute( 'data-folder' );
                    var l = document.location.href + "?folder=" + src;
                    document.location.href = l;
                }
            }
        }
        // When the user clicks on <span> (x), close the modal
        span.addEventListener( 'click', function( event ) {
            modal.classList.toggle( 'hidden' );
            //content.innerHTML = '';
            try {
                //content.innerHTML = "<span class='pull-right modal-close'>&times;</span>";
                content.removeChild( content.children[0] );
            } catch( e ) {}
        }, false );
        /*
        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                //modal.style.display = "none";
                modal.classList.toggle( 'hidden' );
                try {
                    content.removeChild( content.firstElementChild );
                } catch( e ) {}
            }
        }
        */
    } catch( e ) {
        console.warn( "\r\n" + e + "\r\n" );
    }
    </script>

<!--
    <script>
        for( var i=0; i<images.length; i++ ) {
            var img = images[i];
            img.src = img.getAttribute( 'data-src');
            img.removeAttribute( 'data-src' );
        }
    </script>
-->
