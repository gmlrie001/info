
	<!-- MODAL(s) SECTION -->
    <section class="wrapper">
        <section id='image-view' class='modal-container hidden'>
            <div class='modal-wrapper'>
                <div class="modal-hdr" role='header'>
                    <div class='filename'>
                        <h1></h1>
                    </div>
                </div>
                <div class='modal-content modal-center-center'>
                    <div class="top-bar clearfix">
                        <span class='pull-right modal-close'>&times;</span>
                    </div>
                    <div class='image-container'></div>
                </div>
                <div class='modal-ftr hidden'>
                    <div class='meta-data'></div>
                </div>
            </div>
        </section>
        <?php foreach( $modal as $k=>$v ) { $m = $v;?>
        <section class="modal-container hidden" id="<?php echo $m['ID']; ?>" role="dialog">
            <div class="modal-wrapper">
                <div class="modal-hdr" style="background-color:#181818;">
                </div>
                <div class="modal-content modal-center-center">
                    <div class="top-bar clearfix" style="background-color:#181818;">
                        <div class="pull-left vault-logo">
                            <!--img class="img-fluid img-responsive" src="/assets/images/vault/logo/vault-logo-white.svg" alt="Vault" style="display:inline-block;"-->
                            <h1 class="d-inline" style="display:inline-block;margin-left:3rem;font-size:2rem;">File Manager</h1>
                        </div>
                        <span class="pull-right modal-close">&times;</span>
                    </div>
                    <div class="modal-content-title">
                        <h2><?php echo $m['title']; ?></h2>
                    </div>
                    <?php
                        foreach( $m['form_elements'] as $element ) {
                            echo $element;
                        }
                    ?>
                </div>
                <div class="modal-ftr">
                    <div class="meta-data"></div>
                </div>
            </div>
        </section>
        <?php } ?>
    </section>

    <script>
    try {
        // Get the modal
        var modal = document.querySelector('#image-view.modal-container'),
        content   = document.querySelector('#image-view.modal-container .modal-content .image-container'),
        // Get the button that opens the modal
        btns      = document.querySelectorAll(".img-thumb"),//[0];
        // Get the <span> element that closes the modal
        span      = document.querySelector("#image-view .modal-close");

        for( var n=0; n<btns.length; n++ ) {
            var btn = btns[n];
            // When the user clicks on the button, open the modal 
            btns[n].onclick = function() {
                if ( this.hasAttribute( 'data-source' ) ) {
                    var img_dims  = {},
                        img_style,
                    img_cont_dims = {'w':960,'h':640,};
                    var src = this.getAttribute( 'data-source' ),
                        tex = src.split( '.' ),
                        ext = tex[tex.length - 1];
                    full_img = document.createElement( 'img' );
                    /* Set image attributes etc. and then append to DOM element */
                    full_img.src = src; //http://placehold.it/360x540
                    full_img.alt = 'Image Preview';
                    full_img.classList.add( 'img-center' );
                    full_img.classList.add( 'img-fluid' );
                    full_img.classList.add( 'animated' );
                    full_img.classList.add( 'hidden' );
                    if ( src.search( 'svg' ) != -1 ) {
                        full_img.classList.add( 'img-svg' );
                    }
                    //content.innerHTML = "<span class='pull-right modal-close'>&times;</span>";
                    content.appendChild( full_img );
                    modal.classList.toggle( 'hidden' );
                    /* Set image dimensions in styling string */
                    setTimeout( function(){
                        var w, h, f,
                        nw = full_img.naturalWidth,
                        nh = full_img.naturalHeight;
                        if ( nw>=img_cont_dims.w || nh>=img_cont_dims.h ) {
                            f = ( nw>=img_cont_dims.w ) ? img_cont_dims.w/nw : 1;
                            w = full_img.naturalWidth  * f;
                            f = ( nh>=img_cont_dims.h ) ? img_cont_dims.h/nh : 1;
                            h = full_img.naturalHeight * f;
                        }
                        else {
                            w =  full_img.naturalWidth;
                            h = full_img.naturalHeight;
                        }
                        img_dims  = {
                            'w': w,
                            'h': h,
                        };
                        img_style = "width:"+img_dims.w+"px !important;height:"+img_dims.h+"px!important;";
                        /*
                        console.log( (full_img.naturalWidth>=window.innerWidth) ? full_img.naturalWidth*0.33333 : full_img.naturalWidth );
                        console.log( (full_img.naturalHeight>=window.innerHeight) ? full_img.naturalHeight*0.33333 : full_img.naturalHeight );
                        */
                        full_img.setAttribute( 'style', img_style );
                        full_img.classList.toggle( 'hidden' );
                        full_img.classList.toggle( 'fadeIn' );
                    },250);
                } else {
                    var src = this.getAttribute( 'data-folder' );
                    var l = document.location.href + "?folder=" + src;
                    document.location.href = l;
                }
            }
        }
        // When the user clicks on <span> (x), close the modal
        span.addEventListener( 'click', function( event ) {
            modal.classList.toggle( 'hidden' );
            //content.innerHTML = '';
            try {
                //content.innerHTML = "<span class='pull-right modal-close'>&times;</span>";
                content.removeChild( content.children[0] );
            } catch( e ) {}
        }, false );
        /*
        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                //modal.style.display = "none";
                modal.classList.toggle( 'hidden' );
                try {
                    content.removeChild( content.firstElementChild );
                } catch( e ) {}
            }
        }
        */
    } catch( e ) {
        console.warn( "\r\n" + e + "\r\n" );
    }
    </script>

