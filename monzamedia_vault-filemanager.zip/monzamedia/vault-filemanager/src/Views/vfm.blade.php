<?php
    //session_start();
    $get   = isset( $_REQUEST['folder'] ) ? $_REQUEST['folder'] : 'uploads';
    $slf   = ( string ) $_SERVER['REQUEST_URI'];
    $modal = [
        /**/
        'getLink' => [
            'ID'            => 'get-link-modal',
            'title'         => 'Media Item Get-Link',
            'form_elements' => [
                '<textarea data-item-link class="get-link"></textarea>',
                '<div class="modal-interaction">
                    <button id="copy2clip" onclick="copy_link();">Copy Link to Clipboard</button>
                    <button type="submit" id="cancel" onclick="modal_close( event, this );">Cancel</button>
                </div>',
            ],
        ],
        /**/
        'editRename' => [
            'ID'            => 'edit-rename-modal',
            'title'         => 'Media Item Rename',
            'form_elements' => [
                '<label for="ofile">New Filename</label>',
                '<input type="text" name="ofile" id="ofile" placeholder="New Filename">',
                '<div class="modal-interaction">
                    <button type="submit" id="confirm">OK</button>
                    <button type="submit" id="cancel">Cancel</button>
                </div>',
            ],
        ],
        /**/
        'copyDuplicate' => [
            'ID'            => 'copy-duplicate-modal',
            'title'         => 'Media Item Copy/Duplicate',
            'form_elements' => [
                '<!--label for="dst">Copy/Duplicate Location</label-->',
                '<div id="dst"></div>',
                '<input type="hidden" data-dest-dir class="dest-dir text" name="folder">',
                '<div class="modal-interaction">
                    <button type="submit" id="confirm">OK</a>
                    <button type="submit" id="cancel">Cancel</button>
                </div>',
            ],
        ],
        /**/
        'trashRemove' => [
            'ID'            => 'remove-trash-modal',
            'title'         => 'Media Item Remove/Trash',
            'form_elements' => [
                '<div class="confirm-message">
                    <h3>Would you like to remove %_fsObjName_%?</h3>
                </div>',
                '<div class="modal-interaction">
                    <button type="submit" id="confirm">OK</button>
                    <button type="submit" id="cancel">Cancel</button>
                </div>',
            ],
        ],
        /**/
    ];
?>

@extends('layouts.app')

@section('content')
    <!-- VIA Vault Filemanager Package -->
    <div class="container-fluid content">
        <div id="fm" class="loader"></div>
        <section id="filemanager" class="hidden">
            <div class="module-title">
                <h1>FILE MANAGER</h1>
            </div>
            <div class="folder-actions folder-actions-container w-full pull-clear">
                <div class="make-new-folder">
                    <div class="action-button mkdir">
                        <form id="createFolder" method="POST" action="/home/vaultfilemanager/mkdir" class="form-container">
                            <div class="form-title">
                                <h2>New Folder Name</h2>
                            </div>
                            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                            <input type="hidden" name="folder" value="<?php echo $get; ?>">
                            <div class="input-element"><!-- input-element-grid"-->
                                <label for="dir-name" class="grid-align-left grid-item-center mobile-hide tablet-hide">New Folder Name</label>
                                <input id="dir-name" class="grid-align-right grid-item-center" name="makedir" type="text" placeholder="New Folder Name" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false">
                            </div>
                            <button type="submit" class="action-button mkdir clearfix" id="file-upload">
                                <div class="pull-left">
                                    <i class="fa fa-folder-open-o"></i>
                                    <span class="mobile-hide">Create New Folder</span>
                                </div>
                                <div class="pull-right">
                                    <span class="mobile-hide"><img src="/assets/images/filemanager/icons/submit_btn_icon.png" alt=""></span>
                                </div>
                            </button>
                        </form>
                    </div>
                </div><!--/ .make-new-folder /-->
                <div class="media-item-search">
                    <div class="action-button search">
                        <form id="search" method="POST" action="/home/vaultfilemanager/search" class="form-container">
                            <div class="form-title">
                                <h2>Search Media Library</h2>
                            </div>
                            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                            <input type="hidden" name="folder" value="<?php echo $get; ?>">
                            <div class="input-element">
                                <label for="search" class="grid-align-left grid-item-center mobile-hide tablet-hide">Search Media Library</label>
                                <input id="search" class="grid-align-right grid-item-center" name="search" type="text" placeholder="Search ..." autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false">
                            </div>
                            <button type="submit" class="action-button search clearfix" id="media-search">
                                <div class="pull-left">
                                    <i class="fa fa-search"></i>
                                    <span class="mobile-hide">Search</span>
                                </div>
                                <div class="pull-right">
                                    <span class="mobile-hide"><img src="/assets/images/filemanager/icons/submit_btn_icon.png" alt=""></span>
                                </div>
                            </button>
                        </form>
                    </div>
                </div><!--/ .media-item-search /-->
                <div class="new-file-upload">
                    <div class="action-button upload">
                        <form id="fileUploader" method="POST" action="/home/vaultfilemanager/upload" enctype="multipart/form-data" onsubmit="this.lastElementChild.disabled=true; return true;" class="form-container">
                            <div class="form-title">
                                <h2>Upload Media File</h2>
                            </div>
                            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                            <input type="hidden" name="folder" value="<?php echo $get; ?>">
                            <div class="input-element">
                                <label>Choose a file ...</label>
                                <input type="file" name="uploadFile" id="file" class="inputfile grid-align-right grid-item-center" accept="image/*">
                            	<label for="file" class="grid-align-left grid-item-center">Choose File ...</label>
                            </div>
                            <button type="submit" class="action-button upload clearfix" id="file-upload">
                                <div class="pull-left">
                                    <i class="fa fa-upload"></i>
                                    <span class="mobile-hide">Upload File</span>
                                </div>
                                <div class="pull-right">
                                    <span class="mobile-hide"><img src="/assets/images/filemanager/icons/submit_btn_icon.png" alt=""></span>
                                </div>
                            </button>
                        </form>
                    </div>
                </div><!--/ .new-file-upload /-->
            </div><!--/ .folder-actions /-->
            <div class="server-os px-0">
                <p>Total Disk Size: {{ $store_total }}</p>
                <div class="progress clearfix">
                    <div class="progress-bar" role="progressbar" aria-valuenow="{{ $disk_stats }}" aria-valuemin="0" aria-valuemax="100" style="width:{{ $disk_stats }}%">
                        <span class="progress-used">{{ $disk_stats }}% Used</span>
                    </div>
                    <div class="progress-bar-remain " style="width: calc( 100% - {{ $disk_stats }}% );">
                        <span class="progress-available">{{ 100 - $disk_stats }}% Free</span>
                    </div>
                </div>
            </div>
            <div class="media-nav-history">
                <div class="humburger">
                    <p>
                        <a href="#media_nav" id="access_nav" class="access_aid">Skip to navigation</a>
                    </p>
                </div>
                <nav id="media_nav" role="navigation">
                    {!! $breadcrumbs !!}
                    <div class="folder-size px-2">
                        <h2>Folder Size: {{ $folder_size }}</h2>
                    </div>
                    <div class="navito-trash">
                    @if ( ! preg_match( '/_trash/i', htmlspecialchars( $_SERVER['REQUEST_URI'], ENT_QUOTES, 'UTF-8' ), $m ) )
                        <h3>
                            <a href="vaultfilemanager/?folder={{ $trash_can }}" title="Goto Trash Can">
                                <span class="mobile-hide">Goto </span>
                                <img class="icon" id="goto-trash" src="/assets/images/helper_icons/icons/trash.svg" alt="Goto Trash Can">
                            </a>
                        </h3>
                    @endif
                    </div>
                </nav>
            </div>

            @if ( isset( $_SESSION['search'] ) )
            <div class="search-result-title">
                <h1 style="display:block;max-width:100%;width:100%;margin:1rem auto;padding:0.75rem 0.25rem;">Search Results</h1>
            </div>
            @endif

            <section class="media-library content-container">

            @if ( isset( $_SESSION['search'] ) )
                <!--h1 style="display:block;max-width:100%;width:100%;margin:0.5rem auto;padding:0.25rem 0.75rem;">Search Results</h1-->
                @foreach( $media_search as $media_item )
                {{-- {!! $media_item !!} --}}
                    {{-- dd( $media_item ) --}}
                    @if( $media_item['kind'] === 'folder' || $media_item['type'] === 'dir' )
                        @include( 'vaultfilemanager::folders' )
                    @elseif( $media_item['type'] === 'file' )
                        @include( 'vaultfilemanager::files' )
                {{--
                __FUTURE__
                    @elseif( $media_item['type'] === 'link|other' )
                    @else
                 __/\__
                --}}
                    @endif
                @endforeach
            @else
                {{-- dd( $media_objects ) --}}
                @foreach( $media_objects as $media_item )
                    @if( $media_item['kind'] === 'folder' || $media_item['type'] === 'dir' )
                        @include( 'vaultfilemanager::folders' )
                    @elseif( $media_item['type'] === 'file' )
                        @include( 'vaultfilemanager::files' )
                {{--
                __FUTURE__
                    @elseif( $media_item['type'] === 'link|other' )
                    @else
                 __/\__
                --}}
                    @endif
                @endforeach
            @endif

            </section><!--/ .media-library.content-container /-->
        </section><!--/ FileManager COMPONENT ID_tag /-->
    </div><!--/ Fluid Container /-->

    {{-- --}}
    @include( 'vaultfilemanager::modal' )

    {{-- --}}
    @include( 'vaultfilemanager::include_scripts' )

@endsection
