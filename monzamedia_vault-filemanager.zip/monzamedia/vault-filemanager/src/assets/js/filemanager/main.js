function elementInViewport( el ) {
    var rect = el.getBoundingClientRect()
    return (
          rect.top  >= 0 
       && rect.left >= 0 
       && rect.top  <= ( window.innerHeight || document.documentElement.clientHeight )
    );
}

function loadImage( el, fn ) {
    var img = new Image(),
        src = el.getAttribute( 'data-src' );
    img.onload = function( ) {
      if ( !! el.parent )
        el.parent.replaceChild( img, el )
      else
        el.src  = src;
      fn ? fn() : null;
    }
    img.src = src;
}

var processScroll = function() {
    for (var i = 0; i < images.length; i++) {
        if ( elementInViewport( images[i] ) ) {
            loadImage( images[i], function() {
                return;
            });
        }
    };
}

var addListener = function( evt, fn ) {
    if ( window.addEventListener ) {
        this.addEventListener( evt, fn, false )
    } else if ( window.attachEvent ) {
        this.attachEvent( 'on' + evt, fn )
    } else {
        this['on' + evt] = fn
    }
},
_has = function( obj, key ) {
    return Object.prototype.hasOwnProperty.call( obj, key );
};


document.onreadystatechange = () => {
    if ( document.readyState === 'complete' ) {
        // document ready
        images = document.querySelectorAll( 'img[data-src]' );
        processScroll();
        addListener( 'scroll', processScroll, false );
        /*
        font_reset();
        window.addEventListener( 'resize', font_reset, false );
        */
       m = new modals();
    }
    //processScroll();
};
  
function validate( form ) {
    valid = true;
    message = {
        'file'   : 'Do you really want to trash this item?',
        'folder' : 'This will trash the folder and ALL its contents. Do you want to continue?',
        'general': 'Do you really want to remove this item (and ALL its contents)?',
    }
    // validation code here ...
    if( ! valid ) {
        alert( 'Please correct the errors in the form!' );
        return false;
    }
    else {
        type = form.hasAttribute( 'data' ) ? form.getAttribute( 'data' ) : 'general';
        return confirm( message[type] );
    }
}

function show_prompt( e, pstr ) {
    e.preventDefault();
    alert( pstr );
}
function handle_form_submission( e ) {
    e.preventDefault();
    console.log( 'Edit/Rename' );
    alert( 'Edit/Rename' );
    console.log( e.target );
}
function rename_handle( e, form_btn ) {
    console.log( e );
    console.log( form_btn );
    console.log( form_btn.parentNode );
    var form_i = form_btn.parentNode.elements.ifile.value;
    var form_o = form_btn.parentNode.elements.ofile;
    var o = prompt( "Please enter a new name:", form_i );
    if ( o != null ) {
        form_o.value = o;
        return;
    } else {
        e.preventDefault();
        return;
    }
}
function copy_handle( e, form_btn ) {
    var form_s = form_btn.parentNode.elements.src.value;
    var form_d = form_btn.parentNode.elements.dst;
    var d = prompt( "Please enter copy destination:", "" );
    if ( d != null || d !='' ) {
        form_d.value = d;
        return;
    }
}

var modals = function( modal_sel ) {
    var modal_sel,
    fnc_dict = {
        'edit'   : '#edit-rename-modal',
        'remove' : '#remove-trash-modal',
        'copy'   : '#copy-duplicate-modal',
    };
}

modals.prototype.edit = function( evt ) {
    //var s, f, t, inme, mid, minp, span,
    //cfm, cnl, mdl, spn, tmp, idx, inp;

    evt.preventDefault();
    s = evt.srcElement;
    f = s.closest( 'form' );
    t = f.elements.ofile;
    //( s.tagName === 'BUTTON' ) ? s.previousElementSibling : s.parentNode.previousElementSibling;
    inme = f.elements.ifile.value;
    //document.querySelector( 'input[name=ifile]' ).value;
    mid  = '#edit-rename-modal';
    minp = mid + ' ' + 'input#ofile';
    //console.log( s ); console.log( t );
    inme_extn = inme.match( /(\.\w{2,5})?$/ig )[0];
    console.log( inme );
    console.log( inme_extn );
    document.querySelector( minp ).value = inme.replace( /(\.\w{2,5})?$/ig, '' );

    span = mid + ' .modal-close';
    cfm  = document.querySelector( mid + ' button#confirm' );
    cnl  = document.querySelector( mid + ' button#cancel' );
    mdl  = document.querySelector( mid );
    spn  = document.querySelector( span );
    tmp  = mdl.lastElementChild.children[1].children;
    tmp  = Array.prototype.slice.call( tmp );
    //console.log( tmp );
    idx  = tmp.map( tmp => tmp.id ).indexOf( 'ofile' );
    inp  = tmp[idx];
    //console.log( inp + "\r\n" + idx );
    //console.log( inp.value );
    mdl.classList.toggle( 'hidden' );
    inp.onchange = function() {
        //console.log( t );
        //console.log( this.value );
        if ( inp.value === undefined || inp.value === "" || inp.value === null ) {
            inp.setAttribute( 'invalid', '' );
            inp.classList.add( 'invalid' );
            return;
        }
        t.value = this.value + inme_extn;
    };
    //return;
    spn.onclick = function() {
        modal_close( null, spn );
    }
    cfm.onclick = function() {
        mnp = inp.value + inme_extn;
        if ( t.value === undefined || t.value === "" || t.value === null ) {
            inp.setAttribute( 'invalid', '' );
            inp.classList.add( 'invalid' );
            return;
        } else {
            t.value = mnp;
        }
        console.log( mnp );
        console.log( t.value );
        //setTimeout( function() { f.submit() }, 100 );
        f.submit();
        modal_close( null, cfm );
    }
    cnl.onclick = function() {
        modal_close( null, cnl );
    }
    return;
}

modals.prototype.remove = function( evt ) {
    evt.preventDefault();
    s = evt.srcElement;
    f = s.closest( 'form' );
    mid = '#remove-trash-modal';
    span = mid + ' .modal-close';
    cfm  = document.querySelector( mid + ' button#confirm' );
    cnl  = document.querySelector( mid + ' button#cancel' );
    mdl  = document.querySelector( mid );
    spn  = document.querySelector( span );
    mdl.classList.toggle( 'hidden' );
    spn.onclick = function() {
        modal_close( null, spn );
    }
    cfm.onclick = function() {
        f.submit();
        modal_close( null, cfm );
    }
    cnl.onclick = function() {
        modal_close( null, cnl );
    }
    return;
}

modals.prototype.copy = function( evt ) {
    update_sel( );
    var seli;
    evt.preventDefault();
    s = evt.srcElement;
    f = s.closest( 'form' );
    //t = s.parentNode.previousElementSibling;
    t = ( s.tagName === 'BUTTON' ) ? s.previousElementSibling : s.parentNode.previousElementSibling;
    //console.log( t );
    //return;
    mid  = '#copy-duplicate-modal';
    span = mid + ' .modal-close';
    txta = 'input[name=folder].dest-dir';
    setTimeout( function() {
        seli = document.querySelectorAll( mid + ' ' + 'input[name=folder]' );
        n = seli.length; for (var i=0; i<n; i++) { var sel = seli[i]; sel.onkeypress = function() { t.value = this.value; } };
    }, 500 );
    cfm  = document.querySelector( mid + ' button#confirm' );
    cnl  = document.querySelector( mid + ' button#cancel' );
    mdl  = document.querySelector( mid );
    spn  = document.querySelector( span );
    mdl.classList.toggle( 'hidden' );
    spn.onclick = function() {
        modal_close( null, spn );
    }
    cfm.onclick = function() {
        selectedValue = document.querySelector( mid + " input[name='folder']:checked" );
        t.value = selectedValue.value;
        f.submit();
        modal_close( evt, cfm );
    }
    cnl.onclick = function() {
        modal_close( evt, null );
    }
    return;
}

function modal_close( evt, e=null ) {
    if ( evt ) {
        var m = evt.target.closest( '.modal-container' );
    } else {
        var m = e.closest( '.modal-container' );
    }
    console.log( m );
    m.classList.toggle( 'hidden' );
}

function update_sel() {
    var  id = '#dst',// id = 'select#dst',
    mdl_sel = document.querySelector( id ),
    url_get = window.location.pathname + '/dirtree',//encodeURIComponent( '/dirtree' ),
    xhr     = new XMLHttpRequest;

    xhr.onreadystatechange = function() {
        if ( this.readyState === 4 && this.status === 200 ) {
            opts = JSON.parse( this.response );
            mdl_sel.innerHTML = opts;
            /*
            n    = opts.length;
            for( var i=0; i<n; i++ ) {
                var o = document.createElement( 'option' );
                opt   = ( opts[i] == '' ) ? './' : opts[i];
                o.value     = opt;
                o.innerText = ( opt != './' ) ? opt : 'uploads/images';
                mdl_sel.appendChild( o );
            }
            */
        }
    };
    
    xhr.open( 'GET', url_get, true );
    //xhr.setRequestHeader( 'X-Requested-With', 'XMLHttpRequest' );
    //xhr.setRequestHeader( 'content-type', 'application/json' )
    xhr.send();
    console.log( xhr.getAllResponseHeaders() );
}

function get_link( lnk ) {
    var copyText =  document.getElementById( "the-link" );
    var tooltip  = document.getElementById( "myTooltip" );
    copyText.select();
    document.execCommand( "copy" );
    tooltip.innerHTML = "Copied: " + copyText.value;
}
function get_link( evt, elm ) {
    //console.log( elm );
    //return;
    var doc_root = window.location.origin,
    evt, elm, modalTgt, modalTgl, tgt;
    evt.preventDefault();
    element = elm;

    fullpath = element.previousElementSibling.value;

    modalTgt = elm.hasAttribute( 'data-target' ) ? 
                elm.getAttribute( 'data-target' ) : null;
    modalTgl = elm.hasAttribute( 'data-toggle' ) ? 
                elm.getAttribute( 'data-toggle' ) : null;

    txt = document.querySelector( modalTgt + " textarea" );
    txt.value = doc_root + '/' + fullpath;

    tgt = document.querySelector( modalTgt );
    tgt.classList.toggle( modalTgl );
    span = document.querySelector( modalTgt + ' .modal-close' );
    span.onclick = function() { tgt.classList.toggle( modalTgl ) };
}
function copy_link() {
    var copyText = document.querySelector( "#get-link-modal [class*=link]" );
    console.log( copyText );
    copyText.select();
    document.execCommand( "copy" );
}
/*
/* onmouseout :--> "show_tooltip()" */
/*
function show_tooltip() {
    tooltip = document.getElementById( "myTooltip" );
    tooltip.innerHTML = "Copy to clipboard";
}
*/

function font_reset() {
    var compressor = 13;
    var fontsize = Math.max(
        Math.min( window.innerWidth / ( compressor * 10 ), parseFloat( 34 ) ), parseFloat( 12 )
    );

    //HTML
    document.documentElement.setAttribute( 'style', 'font-size: ' + Math.ceil( fontsize ) + 'px' );
    //BODY
    document.body.setAttribute( 'style', 'font-size: ' + Math.ceil( fontsize ) + 'px' );
}
