<?php
/**
 * Vault Filemanager Configuration File
 * 
 * file: config.php
 * _mrg
 * Jun - Sep 2018
 * 
 */
return [
    'version'    => '',
    'authors'    => [],
    'licence(s)' => [],
    //'' => ,
    /**
     * List of ALL File Type Uploads Allowed.
     * 
     */
    'allowed_types' => [
        'csv',
        'txt',
        'doc', 'docx',
        'xls', 'xlsx',
        'pdf',
        'gif', 'jpg', 'jpeg', 'png', 'svg',
        'rar', 'zip',
    ],
    /**
     * Subset of above
     * List of ALL File Type Uploads Allowed.
     * 
     */
    'allowed_images'=> [
        'gif',
        'jpg',
        'jpeg',
        'png',
        'svg',
    ],
    /**
     * File Kind/Mimetype Icon Image Links, this
     * excludes JPG, PNG and GIF images since
     * their thumbnails are used as icons.
     * 
     */
    'file_kinds' => [
        'rar'  => [
            'fa fa-file-word-o',
            'filemanager/icons/file_rar_icon.png',
            'filemanager/icons/svg/file_rar_icon.svg'
        ],
        'zip'  => [
            'fa fa-file-word-o',
            '/assets/images/filemanager/icons/file_zip_icon.png',
            '/assets/images/filemanager/icons/svg/file_zip_icon.svg'
        ],
        'txt'  => [
            'fa fa-file-word-o',
            '/assets/images/filemanager/icons/file_txt_icon.png',
            '/assets/images/filemanager/icons/svg/file_txt_icon.svg'
        ],
        'csv'  => [
            'fa fa-file-word-o',
            '/assets/images/filemanager/icons/file_csv_icon.png',
            '/assets/images/filemanager/icons/svg/file_csv_icon.svg'
        ],
        'pdf'  => [
            'fa fa-file-pdf-o',
            '/assets/images/filemanager/icons/file_pdf_icon.png',
            '/assets/images/filemanager/icons/svg/file_pdf_icon.svg'
        ],
        'doc'  => [
            'fa fa-file-word-o',
            '/assets/images/filemanager/icons/file_docx_icon.png',
            '/assets/images/filemanager/icons/svg/file_docx_icon.svg'
        ],
        'docx' => [
            'fa fa-file-word-o',
            '/assets/images/filemanager/icons/file_docx_icon.png',
            '/assets/images/filemanager/icons/svg/file_docx_icon.svg'
        ],
        'xls'  => [
            'fa fa-file-word-o',
            '/assets/images/filemanager/icons/file_xlsx_icon.png',
            '/assets/images/filemanager/icons/svg/file_xlsx_icon.svg'
        ],
        'xlsx' => [
            'fa fa-file-word-o',
            '/assets/images/filemanager/icons/file_xlsx_icon.png',
            '/assets/images/filemanager/icons/svg/file_xlsx_icon.svg'
        ],
        'unknown' => [
            'fa fa-question',
            '',
            ''
        ],
    ],
    /**
     * 
     * DEFAULT Vault Filemanager Package Values
     * 
     *   1 - Vault Filemanager UMASK;
     *   2  file and folder permission;
     *   3- default timezone; and
     *   4- new FS objects (file, etc.).
     *    * JP[e]Gs, PNGs and GIFs are excluded
     *      from this list, since their
     *      thumbnails are used as icons.
     *
     */

    /* Default values for Vault Filemanager UMASK */
    'vfm_umask' => 0022,
    /* Default values for file & folder permissions */
    'new_obj_perms' => [
        'file' => 0644,
        'directory' => 0755,
    ],
    /* Default values for timezone - should pickup from LOCALE */
    'default_timezone' => 'Africa/Johannesburg',
    /* Default values for new FS objects (file, folder, symlink) */
    'defaults' => [
        'new_img' => 'New-File.txt',
        'new_dir' => 'New-Folder',
        'new_lnk' => 'New-Symlink.lnk',
    ],
];
