<?php namespace Monzamedia\VaultFilemanager;


function vfm_html_render() {
    $opened_tag = array();
    $h = "";
    /**
     *  FOLDERS */
    if ( $type == 'dir' ) {
        /**/
        $h  = '<div class="media-item">';
        /**/
        $h .=   '<div id="' . $fnme . '" class="media-card-container dshadow1">';
        $h .=       '<div class="item-type-folder">';
    /* Make the image and text linkable to the linked folder for type=DIR */
        $h .= "<a class='padme' title='Folder' href='vaultfilemanager?folder=$fullpath'>";
        $opened_tag[] = true;
        $open_tag[]   = 'a';
    /* IMAGE */
        $img = "<img data-folder='$fullpath' ";
        $opened_tag[] = true;
        $open_tag[]   = 'img';
    /* SRC and DATA-SRC specifications */
        $h .=     $img . "src='http://via.placeholder.com/120x80' class='lazy folder mm-ml-icon img-thumb center-center' data-src='/assets/images/filemanager/icons/svg/file_folder_icon.svg' alt='Folder'>";
        array_pop( $opened_tag );
        array_pop( $open_tag );
    /* CLOSE type=DIR folder link */
        $h .= "</a>";
        array_pop( $opened_tag );
        array_pop( $open_tag );
    /**
    *  FILES */
    } else {
        $h  = '<div class="media-item">';
        $h .= '<div class="padme">';
        $opened_tag[] = true;
        $open_tag[]   = 'div';
        $h .=   '<div id="'.$fnme.'" class="media-card-container dshadow1">';
    /* Markup for image extension SVG not in allowed file types extensions */
        if ( ( in_array( strtolower( $kind ), $this->allowedTypes['allowed_images'] ) ) && strtolower( $kind ) == 'svg' ) {
            $h .=    '<div class="item-type-image">';
            $thmb_dst     = '/' . $fullpath ;
            $img          = "<img src='http://via.placeholder.com/120x80' class='lazy file center-center mm-ml-tn img-thumb bg-black' data-src='" . $thmb_dst;
            $opened_tag[] = true;
            $open_tag[]   = 'img';
    /* Markup for images that are in allowed file types extensions */
        } else if ( in_array( strtolower( $kind ), $this->allowedTypes['allowed_images'] ) ) {
            $h .=    '<div class="item-type-image">';
            $thmb_dst = $thumb_pth;
            if ( ! preg_match( '/thumb{2}/i', $thmb_dst, $m ) ) {
                if ( ! file_exists( $thmb_dst ) ) {
                    $thmb_dst = $this->createThumbnail( $fullpath, $thmb_dst, 120 );
                }
    /*
                else {
                    $week_sec = ( int ) ( 7 * 24 * 3600 );
                    $ftdelta  = stat( $thmb_dst )['mtime'] - stat( $thmb_dst )['ctime'];
                    $dummy_cache_logic = file_exists( $thmb_dst ) && ( abs( $ftdelta ) > $week_sec );
                    ( $dummy_cache_logic ) ? touch( $thmb_dst ) : $this->createThumbnail( $fullpath, $thmb_dst, 120 );
                }
    */
            }
            $img          = "<img src='http://via.placeholder.com/120x80' class='lazy image center-center mm-ml-tn img-thumb' data-src='/" . $this->show_relpath( $thmb_dst );
            $opened_tag[] = true;
            $open_tag[]   = 'img';
    /* Markup for allowed "other" file type extensions in addition to images */
        } else if ( in_array( strtolower( $kind ), array_keys( $this->otype_arr ) ) ) {
            $h .=    '<div class="item-type-file center-center">';
            $img          = '<img class="'.$kind.' dshadow1 center-center" src="'.$this->otype_arr[$kind][2].'"';
            $opened_tag[] = true;
            $open_tag[]   = 'img';
    /* Markup for other/UNKNOWN file types extensions not in the recognized other file types array */
        } else {
            $h .=    '<div class="item-type-file center-center">';
            $img          = '<i class="'.$this->otype_arr['unknown'].' dshadow1 center-center">';
            $opened_tag[] = true;
            $open_tag[]   = 'i';
        }
    /* CLOSE IMAGES and/or i and SPAN tags */
        if ( preg_match( '/img/i', $img, $m ) ) {
            $h .= $img . "' alt='$type=>type:$kind;name:$name' data-source='/" . $fullpath . "'>";
        } else {
            $h .= $img . '<span class="file-kind">' . $kind . '</span></i>';
        }
        array_pop( $opened_tag );
        array_pop( $open_tag );
    }
    $h .=   "</div><!--/ .item-type-folder||.item-type-file -->";
    $h .=   '<div class="metadata">';
    /* Make the image and text linkable to the linked folder for type=DIR */
    if ( $type == 'dir' ) {
        $h .= "<a class='padme' title='Folder' href='vaultfilemanager?folder=$fullpath'>";
        $opened_tag[] = true;
        $open_tag[]   = 'a';
    }
    /* METADATA section */
    $nme = $this->chop_string( $name, 24 );
    $h .=     "<div class='item-name'><h2><abbr title='/$fullpath'>" . $this->urlify_filenames( $nme ) . "</abbr></h2></div>";
    $sc = ( $type == 'dir' ) ? 
                '<abbr title="Folder Item Count">' . $szcnt['items'] . ' Items</abbr>' : 
                '<span class="mobile-hide tablet-hide">File Size: </span>' . $szcnt['human'];
    $h .=     "<div class='item-size-count'><p>" . $sc . "</p></div>";
    $h .=     "<div class='item-last-modified'><p><span class='mobile-hide tablet-hide'><abbr title='Modification Time'>Mod:</abbr></span> " . $stats['modify'] . "</p></div>";
    /* CLOSE type=DIR folder link */
    if ( $type == 'dir' ) {
        $h .= "</a><!-- padme anchor-link tag -->";
        array_pop( $opened_tag );
        array_pop( $open_tag );
    }
    $h .=   "</div><!--/ .metadata -->";

    /* MEDIA Actions Container */
    $s = urldecode( $name );
    if ( ! in_array( $s, [ 'media_thumbs', '_trash' ] ) ) {
        $h .=   '<div class="media-item-actions-container">';
    } else {
        $h .=   '<div class="media-item-actions-container not-removable">';
    }
    /* Edit/Rename */
    $fn = $this->urlify_filenames( $name );
    // Current Working Directory (cwd)
    $p = isset( $_REQUEST['folder'] ) ? $_REQUEST['folder'] : $path;
    if ( ! in_array($s, [ 'media_thumbs', '_trash' ])) {
        $h .= '<form class="media-item-action edit" id="edit" method="POST" action="vaultfilemanager/rename" onsubmit="event.preventDefault();">
                    <input type="hidden" name="_token" value="' . csrf_token() . '">
                    <input type="hidden" name="folder" value="' . $p . '">
                    <input type="hidden" name="ifile" value="' . $name . '">
                    <input type="hidden" name="ofile">
                    <button class="action-icons center-center" type="submit" id="rename-image" onclick="m.edit( event );">
                        <img src="/assets/images/helper_icons/icons/edit.svg">
                    </button>
                </form>';
    }
    /* Open Folder or Download File */
    if ( $type == 'dir' ) {
    /* Make the image and text linkable to the linked folder for type=DIR */
        $h .= "<div class='media-item-action open-folder'>
                <a class='padme' title='Folder' href='?folder=$fullpath'>";
        $opened_tag[] = true;
        $open_tag[]   = 'a';
        $h .=     '<i class="fa fa-folder-open-o action-icons center-center"></i>';
        $h .= "</a></div>";
        array_pop( $opened_tag );
        array_pop( $open_tag );
    } else {
        $h .= '<!--div class="media-item-action download"-->
                <a class="media-item-action download" title="Media Object Download" href="../' . $fullpath. '" download>
                    <img class="action-icons center-center" src="/assets/images/helper_icons/icons/download.svg">
                </a>
            <!--/div-->';
    }
    /* Copy/Duplicate a File or Folder to a specified destination */
    // Current Working Directory (cwd)
    //$p = isset( $_REQUEST['folder'] ) ? $_REQUEST['folder'] : $path;
    if (! in_array($s, [ 'media_thumbs', '_trash' ])) {
        $h .= '<form class="media-item-action copy" id="copy" method="POST" action="vaultfilemanager/copy">
                <input type="hidden" name="_token" value="' . csrf_token() . '">
                <input type="hidden" name="folder" value="' . $p . '">
                <input type="hidden" name="src" value="' . $name . '">
                <input type="hidden" name="dst">
                <button type="submit" class="action-icons center-center" id="copy-image" onclick="m.copy( event, this );">
                    <img src="/assets/images/helper_icons/icons/copy.svg">
                </button>
            </form>';
    }
    /* Get the item link/URI with option to copy to clipboard */
    $h .= '<form class="media-item-action link" id="link" method="" action="">
                <!--input type="hidden" name="_token" value="' . csrf_token() . '"-->
                <input type="hidden" name="folder" value="' . $p . '">
                <input id="the-link" type="hidden" name="link" value="' . $fullpath . '">
                <button type="submit" class="action-icons center-center" id="link-image" data-target="#get-link-modal" data-toggle="hidden" onclick="event.preventDefault(); get_link( event, this );">
                    <img src="/assets/images/helper_icons/icons/link.svg">
                </button>
            </form>';            
    /* Move item to trash or (if in trash) Delete item */
    if ( ! in_array( $s, [ 'media_thumbs', '_trash' ] ) ) {
        $h .= '<form class="media-item-action delete" id="delete" method="POST" data="'. $kind . '" action="vaultfilemanager/trash">
                    <input type="hidden" name="_token" value="' . csrf_token() . '">
                    <input type="hidden" name="folder" value="' . $p . '">
                    <input type="hidden" name="trash" value="' . $s . '">
                    <button type="submit" class="action-icons center-center" id="trash-image" onclick="m.remove( event, this );">
                        <img src="/assets/images/helper_icons/icons/trash.svg">
                    </button>
                </form>';
    }
    $h .=   '</div><!--/ .media-item-actions-container -->';
    $h .=  "</div><!--/ .media-item-container -->";

    $h .= "</div>";
    if ( $type != 'dir' ) {
        $h .= "</div>";
        array_pop( $opened_tag );
        array_pop( $open_tag );
    } else {
        /* HANDLE ALL OPENED TAGS */
        if ( ! empty( $opened_tag ) && ! empty( $open_tag ) ) {
            $t1 = array_reverse( $opened_tag );
            $t2 = array_reverse(   $open_tag );
            if ( count( $t1 ) === count( $t2 ) ) {
                $n = count( $t1 );
                for ( $i = 0; $i<$n; $i++ ) {
                    $idnt_rpt = str_repeat( "\t", (int) ( $n - 1 - $i ) );
                    $h .= "</" . $t2[$i] . ">\r\n";
                    array_pop( $t1 );
                    array_pop( $t2 );
                    $n--;
                }
            }
        }
    }
    return $h;
}
